from __future__ import annotations

from collections.abc import Callable, Iterable
from pathlib import Path
from typing import TYPE_CHECKING, Any

from pydantic_ai import FunctionToolset
from pydantic_ai.agent import Agent

from avb_llm.agents.agents_model import (
    CATEGORY_REGISTRY,
    OrchestratorAgentController,
    make_delegation_tool,
)
from avb_llm.agents.base_agent_controller import BaseAgentController
from avb_llm.agents.base_agent_model import AppConfig, BaseAgentConfigModel

if TYPE_CHECKING:
    from avb_llm.session import AgentSessionController, AgentSessionModel


def _dedup(raw_list: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for r in raw_list:
        meta = {k: v for k, v in r.items() if not k.startswith("@")}
        key = str(meta.get("url") or meta.get("path") or meta.get("id"))
        page = meta.get("page")
        content = meta.get("content")
        score = r.get("@search.score")
        if key not in out:
            out[key] = {
                "id": key,
                "title": meta.get("title") or meta.get("path"),
                "url": meta.get("url"),
                "filepath": meta.get("path"),
                "pages": [],
                "snippets": [],
            }
        if page is not None and page not in out[key]["pages"]:
            out[key]["pages"].append(page)
        if content:
            out[key]["snippets"].append({"page": page, "content": content, "score": score})
    for item in out.values():
        item["pages"].sort()
        item["snippets"].sort(key=lambda s: (s["page"] is None, s["page"]))
    return list(out.values())


class AgentInitPipeline:
    def __init__(self, app_config: AppConfig) -> None:
        """
        Initialize the agent pipeline with the application configuration.

        Args:
            app_config (AppConfig): The validated application configuration.
        """
        self.app_config: AppConfig = app_config

    def build_agent_pipeline(
        self,
        agent_names: list[str] | None = None,
        sub_agent_names: list[str] | None = None,
        extra_tools: dict[str, list[Any]] | None = None,
    ) -> tuple[dict[str, BaseAgentController], dict[str, Agent[Any, Any]]]:
        """
        Build the agent controllers and agents defined in the configuration.

        Constructs an orchestrator with delegation tools when sub-agents are given,
        and otherwise builds each configured agent by its registered category.

        Args:
            agent_names (list[str] | None): Names of agents to build. Defaults to all configured agents.
            sub_agent_names (list[str] | None): Names of sub-agents the orchestrator may delegate to. Defaults to None.
            extra_tools (dict[str, list[Any]] | None): Additional tools to attach per agent. Defaults to None.

        Returns:
            tuple[dict[str, BaseAgentController], dict[str, Agent[Any, Any]]]: The built
                controllers and agents keyed by name.

        Raises:
            ValueError: If an agent has an unknown type not present in the registry.
        """
        factories: dict[str, BaseAgentController] = {}
        agents: dict[str, Agent[Any, Any]] = {}

        names: list[str] = agent_names if agent_names is not None else list(self.app_config.agent_configs)

        for agent_name in names:
            agent_config: BaseAgentConfigModel = self.app_config.agent_configs[agent_name]

            if agent_config.type == "orchestrator":
                call_tools: list[Any] | None = None
                if sub_agent_names:
                    call_tools = [
                        (
                            CATEGORY_REGISTRY[sub_name].call_tool
                            if sub_name in CATEGORY_REGISTRY
                            else make_delegation_tool(
                                agent_name=sub_name,
                                agent_instructions=self.app_config.agent_configs[sub_name].instructions,
                            )
                        )
                        for sub_name in sub_agent_names
                    ]
                factory: BaseAgentController = OrchestratorAgentController(
                    config=agent_config, sub_agent_names=sub_agent_names, call_tools=call_tools
                )
            else:
                if agent_config.type not in CATEGORY_REGISTRY:
                    raise ValueError(
                        f"Agent '{agent_name}' has unknown type '{agent_config.type}'. "
                        f"Allowed types: {sorted(CATEGORY_REGISTRY)}"
                    )
                factory = CATEGORY_REGISTRY[agent_config.type].factory(config=agent_config)

            if extra_tools and extra_tools.get(agent_name):
                factory.toolsets.append(FunctionToolset(tools=extra_tools[agent_name]))

            agent: Agent[Any, Any] = factory.build_agent()
            factories[agent_name] = factory
            agents[agent_name] = agent

        return factories, agents


class InitializedAgents:
    """Wrapper around a session that lets you attach custom tools before running."""

    def __init__(
        self,
        *,
        config: str | Path | None = None,
        profile: str = "thorough",
        excel_paths: Iterable[str | Path] | None = None,
        debug: bool = False,
    ) -> None:
        """
        Initialize the agent wrapper with its session configuration.

        Args:
            config (str | Path | None): Path to the configuration YAML. Defaults to
                DEFAULT_CONFIG_PATH when None.
            profile (str): Name of the profile to build agents from. Defaults to "thorough".
            excel_paths (Iterable[str | Path] | None): Optional Excel workbook paths to make available. Defaults to None.
            debug (bool): Whether to expose the agent reasoning summary. Defaults to False.
        """
        from avb_llm.session import DEFAULT_CONFIG_PATH, AgentSessionController  # noqa: PLC0415

        self._controller: AgentSessionController = AgentSessionController()
        self._config: str | Path = config if config is not None else DEFAULT_CONFIG_PATH
        self._profile: str = profile
        self._excel_paths: Iterable[str | Path] | None = excel_paths
        self._debug: bool = debug
        self._extra_tools: dict[str, list[Callable[..., Any]]] = {}
        self._session: AgentSessionModel | None = None
        self._sources: list[dict[str, Any]] = []

    def add_tools(self, agent_name: str, tools: list[Callable[..., Any]]) -> InitializedAgents:
        """Register extra tools for a given agent (e.g. 'excel_analyzer')."""
        self._extra_tools.setdefault(agent_name, []).extend(tools)
        self._session = None  # invalidate: session must be rebuilt with the new tools
        return self

    def _build(self) -> AgentSessionModel:
        """
        Build the underlying agent session, creating it on first use.

        The session is cached and rebuilt whenever extra tools are registered.

        Returns:
            AgentSessionModel: The initialized agent session.
        """
        if self._session is None:
            self._session = self._controller.build_from_profile(
                profile_name=self._profile,
                debug=self._debug,
                excel_paths=self._excel_paths,
                config_path=self._config,
                extra_tools=self._extra_tools or None,
                sources=self._sources,
            )
        return self._session

    def run_sync(self, prompt: str, structured: bool = False, file_paths: list[Path] = []) -> str | dict[str, Any]:
        """
        Run a prompt synchronously against the built session.

        Args:
            prompt (str): The user prompt to send to the orchestrator.
            structured (bool): Whether to return a structured response. Defaults to False.

        Returns:
            str | dict[str, Any]: The agent answer, or a structured dictionary when requested.
        """
        session = self._build()
        self._sources.clear()
        result = session.ask_sync(question=prompt, structured=structured, file_paths=file_paths)
        if structured and isinstance(result, dict):
            result["sources"] = _dedup(self._sources)
        return result

    async def run_async(self, prompt: str, structured: bool = False, file_paths: list[Path] = []) -> str | dict[str, Any]:
        """
        Run a prompt asynchronously against the built session.

        Args:
            prompt (str): The user prompt to send to the orchestrator.
            structured (bool): Whether to return a structured response. Defaults to False.

        Returns:
            str | dict[str, Any]: The agent answer, or a structured dictionary when requested.
        """
        session = self._build()
        self._sources.clear()
        result = await session.ask_async(question=prompt, structured=structured, file_paths=file_paths)
        if structured and isinstance(result, dict):
            result["sources"] = _dedup(self._sources)
        return result


def initialize_agents(
    config: str | Path | None = None,
    *,
    profile: str = "thorough",
    excel_paths: Iterable[str | Path] | None = None,
    debug: bool = False,
) -> InitializedAgents:
    """Entry point: build agents from a config.yaml with a single call."""
    return InitializedAgents(
        config=config,
        profile=profile,
        excel_paths=excel_paths,
        debug=debug,
    )
