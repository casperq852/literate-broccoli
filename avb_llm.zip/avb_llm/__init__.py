from dotenv import load_dotenv

# Load a local .env (e.g. AZURE_TOKEN_CREDENTIALS=dev) before any Azure client
# creates a DefaultAzureCredential, so developer sign-in is used over a
# compute managed identity. Existing environment variables take precedence.
load_dotenv(override=False)

from avb_llm.clients import get_search_index_names_and_fields  # noqa: E402
from avb_llm.pipelines.agent_pipeline import InitializedAgents, initialize_agents  # noqa: E402
from avb_llm.session import AgentSessionController, AgentSessionModel  # noqa: E402

__all__ = [
    "AgentSessionController",
    "AgentSessionModel",
    "InitializedAgents",
    "initialize_agents",
    "get_search_index_names_and_fields",
]
