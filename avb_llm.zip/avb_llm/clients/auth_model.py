from __future__ import annotations

import os
from typing import Any

from avb_core import get_logger
from avb_core.loggers import Logger
from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import ClientAuthenticationError
from azure.identity import DefaultAzureCredential, get_bearer_token_provider

logger: Logger = get_logger(name=__name__, structured=True)


def resolve_credential(
    scope: str,
    api_key_env: str,
    service_name: str,
) -> DefaultAzureCredential | AzureKeyCredential:
    """
    Resolve a credential for the given service.

    API key takes priority: if *api_key_env* is set in the environment its value is
    returned as an :class:`AzureKeyCredential` immediately, with no token exchange.
    Only when the environment variable is absent is :class:`DefaultAzureCredential`
    attempted.

    Args:
        scope (str): The Azure token scope URL (e.g. "https://search.azure.com/.default").
            Only used when falling back to DefaultAzureCredential.
        api_key_env (str): Environment variable name that holds the preferred API key.
        service_name (str): Human-readable service label used in log messages.

    Returns:
        DefaultAzureCredential | AzureKeyCredential: The resolved credential.

    Raises:
        ClientAuthenticationError: When no API key is set and DefaultAzureCredential
            also fails to acquire a token.
    """
    api_key: str | None = os.environ.get(api_key_env)
    if api_key:
        logger.info(message=f"{service_name}: using API key from {api_key_env}")
        return AzureKeyCredential(key=api_key)

    logger.info(message=f"{service_name}: no API key found in {api_key_env}; attempting DefaultAzureCredential")
    try:
        credential: DefaultAzureCredential = DefaultAzureCredential()
        credential.get_token(scope)
        logger.info(message=f"{service_name}: using DefaultAzureCredential")
        return credential
    except (ClientAuthenticationError, Exception):
        logger.warning(
            message=f"{service_name}: DefaultAzureCredential failed and no API key is configured "
            f"(set {api_key_env}). Both authentication methods are unavailable."
        )
        raise


def resolve_foundry_auth_kwargs(service_name: str = "AzureAIFoundryClient") -> dict[str, Any]:
    """
    Resolve Azure AI Foundry (Azure OpenAI) authentication and return keyword arguments
    suitable for passing directly to AzureOpenAI / AsyncAzureOpenAI constructors.

    Uses DefaultAzureCredential with a token provider when available; falls back to
    an API key (AZURE_FOUNDRY_API_KEY) otherwise.

    Args:
        service_name (str): Human-readable service label used in log messages.

    Returns:
        dict[str, Any]: Either ``{"azure_ad_token_provider": ...}`` or ``{"api_key": ...}``.
    """
    scope = "https://cognitiveservices.azure.com/.default"
    credential: DefaultAzureCredential | AzureKeyCredential = resolve_credential(
        scope=scope,
        api_key_env="AZURE_FOUNDRY_API_KEY",
        service_name=service_name,
    )
    if isinstance(credential, AzureKeyCredential):
        return {"api_key": credential.key}

    # DefaultAzureCredential — wrap in a token provider as required by the OpenAI SDK.
    token_provider = get_bearer_token_provider(credential, scope)
    return {"azure_ad_token_provider": token_provider}


def resolve_search_credential(service_name: str = "AzureAISearchClient") -> DefaultAzureCredential | AzureKeyCredential:
    """
    Resolve Azure AI Search authentication and return a credential suitable for
    passing directly to SearchClient / SearchIndexClient constructors.

    Uses DefaultAzureCredential when available; falls back to an API key (AZURE_SEARCH_API_KEY)
    otherwise.

    Args:
        service_name (str): Human-readable service label used in log messages.

    Returns:
        DefaultAzureCredential | AzureKeyCredential: The resolved credential.
    """
    scope = "https://search.azure.com/.default"
    return resolve_credential(
        scope=scope,
        api_key_env="AZURE_SEARCH_API_KEY",
        service_name=service_name,
    )
