from __future__ import annotations

import os
from functools import cached_property
from typing import Any

from avb_core import get_logger
from avb_core.loggers import Logger
from azure.core.exceptions import HttpResponseError
from azure.search.documents import SearchClient, SearchItemPaged
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import SearchIndex

from avb_llm.clients.auth_model import resolve_search_credential

os.environ.setdefault(key="LOG_LEVEL", value="DEBUG")
logger: Logger = get_logger(name=__name__, structured=True)


class AzureAISearchClient:
    """
    A wrapper class around the Azure AI Search document service.

    This class provides a simplified interface for interacting with Azure AI Search,
    including document uploading, searching, and vectorized querying capabilities.
    """

    def __init__(self, endpoint: str, index_name: str) -> None:
        """
        Initialize the Azure AI Search client.

        Args:
            endpoint (str): The Azure AI Search endpoint URL.
            index_name (str): The name of the search index to query.
        """
        credential = resolve_search_credential()
        self.index_name: str | SearchIndex = index_name
        self._client: SearchClient = SearchClient(endpoint=endpoint, index_name=index_name, credential=credential)

    @cached_property
    def client(self) -> SearchClient:
        """Return SearchClient Class"""
        return self._client

    def search(self, *args: Any, **kwargs: Any) -> SearchItemPaged[dict[str, Any]]:
        """Perform a search using the Azure Search client."""
        return self.client.search(*args, **kwargs)


def get_search_index_names_and_fields(endpoint: str) -> dict[str, list[str]]:
    """
    Fetch available Azure AI Search index names and their field names.

    Args:
        endpoint (str): The Azure AI Search service endpoint URL.

    Returns:
        dict[str, list[str]]: A mapping of each index name to the list of its
            field names.
    """
    credential = resolve_search_credential()
    index_client: SearchIndexClient = SearchIndexClient(
        endpoint=endpoint,
        credential=credential,
    )
    try:
        index_names: list[str] = list(index_client.list_index_names())
        indices_fields: dict[str, list[str]] = {}
        for index_name in index_names:
            index: SearchIndex = index_client.get_index(name=index_name)
            indices_fields[index_name] = [field.name for field in index.fields]
        return indices_fields
    except HttpResponseError as exc:
        if exc.status_code == 403 or "forbidden" in str(exc).lower():
            raise PermissionError(
                "Access to Azure AI Search was forbidden (403). Before continuing, "
                "make sure you have initialized the configuration (via avb-llm-init) "
                "and signed in to Azure (via az login) then re-run the application."
            ) from exc
        raise
