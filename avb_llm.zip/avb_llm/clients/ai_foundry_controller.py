from __future__ import annotations

from collections.abc import Iterable
from functools import cached_property
from typing import Any

from avb_core import get_logger
from avb_core.loggers import Logger
from openai import AsyncAzureOpenAI, AzureOpenAI
from openai.types.chat import ChatCompletion, ChatCompletionMessageParam

from avb_llm.clients.auth_model import resolve_foundry_auth_kwargs

logger: Logger = get_logger(name=__name__, structured=True)


class AzureAIFoundryClient:
    """Minimal wrapper around Azure AI Foundry (Azure OpenAI) endpoints."""

    def __init__(
        self,
        endpoint: str,
        api_version: str,
        chat_deployment: str,
    ) -> None:
        """
        Initialize the Azure AI Foundry client.

        Args:
            endpoint (str): The Azure OpenAI endpoint URL.
            api_version (str): The Azure OpenAI API version.
            chat_deployment (str): The name of the chat deployment to call.
        """
        self.endpoint: str = endpoint
        self.api_version: str = api_version
        self.chat_deployment: str = chat_deployment
        self._auth_kwargs: dict[str, Any] = resolve_foundry_auth_kwargs()

    @cached_property
    def client(self) -> AzureOpenAI:
        """
        Return the underlying sync Azure OpenAI client.

        Returns:
            AzureOpenAI: The configured sync Azure OpenAI client instance.
        """
        return AzureOpenAI(
            azure_endpoint=self.endpoint,
            api_version=self.api_version,
            **self._auth_kwargs,
        )

    @cached_property
    def async_client(self) -> AsyncAzureOpenAI:
        """
        Return the underlying async Azure OpenAI client.

        Returns:
            AsyncAzureOpenAI: The configured async Azure OpenAI client instance.
        """
        return AsyncAzureOpenAI(
            azure_endpoint=self.endpoint,
            api_version=self.api_version,
            **self._auth_kwargs,
        )

    def chat(self, messages: Iterable[ChatCompletionMessageParam], **kwargs: Any) -> str:
        """
        Send a chat completion request and return the assistant's reply.

        Args:
            messages (Iterable[ChatCompletionMessageParam]): The conversation messages to send.
            **kwargs: Additional keyword arguments forwarded to the completions API.

        Returns:
            str: The content of the first completion choice, or an empty string.
        """
        response: ChatCompletion = self.client.chat.completions.create(
            model=self.chat_deployment,
            messages=list(messages),
            **kwargs,
        )
        return response.choices[0].message.content or ""
