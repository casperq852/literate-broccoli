import shutil
from functools import cache
from importlib.abc import Traversable
from importlib.resources import files
from pathlib import Path
from typing import Any

import yaml
from avb_core import get_logger
from avb_core.loggers import Logger

logger: Logger = get_logger(name=__name__, structured=True)


@cache
def read_yaml_file(location: Path | str) -> dict[str, Any]:
    """
    Read and parse a YAML file.

    This function reads a YAML file located at the specified 'location' and parses its contents into
    a Python dictionary. It handles exceptions for file not found, YAML parsing errors, and other
    general exceptions.

    Parameters:
        location (Path | str): The file path of the YAML file to read and parse.

    Returns:
        dict[str, Any]: A dictionary containing the parsed YAML data.

    Raises:
        FileNotFoundError: If the specified file does not exist.
        yaml.YAMLError: If there is an error in parsing the YAML content.
        Exception: For any other general exceptions that may occur during file reading or parsing.
    """
    try:
        with open(file=location) as yaml_file:  # pylint: disable=unspecified-encoding
            data: dict[str, Any] = yaml.safe_load(stream=yaml_file)
        return data
    except FileNotFoundError as exc:
        raise ValueError(f"The file '{location}' does not exist.") from exc
    except yaml.YAMLError as exc:
        raise ValueError(f"Error parsing '{location}': {exc}") from exc
    except KeyError as exc:
        raise ValueError(f"An error occurred: {exc}") from exc
    except ValueError as exc:
        raise ValueError(f"An error occurred: {exc}") from exc


def ensure_env_variable(key: str, value: str) -> None:
    """
    Ensure a key/value pair exists in the `.env` file in the current directory.

    If `.env` does not exist, it is created containing the variable. If it does
    exist, the variable is appended only when the key is not already present, so
    the existing file content is preserved.

    Parameters:
        key (str): The environment variable name.
        value (str): The value to assign to the environment variable.
    """
    env_path: Path = Path.cwd() / ".env"
    line: str = f'{key}="{value}"'

    if not env_path.exists():
        env_path.write_text(data=f"{line}\n", encoding="utf-8")
        logger.info(message=f"Created .env with {key}")
        return

    content: str = env_path.read_text(encoding="utf-8")
    existing_keys: set[str] = {
        stripped.split(sep="=", maxsplit=1)[0].strip()
        for entry in content.splitlines()
        if (stripped := entry.strip()) and not stripped.startswith("#") and "=" in stripped
    }
    if key in existing_keys:
        logger.info(message=f"{key} already exists in .env, skipping.")
        return

    with open(file=env_path, mode="a", encoding="utf-8") as env_file:
        if content and not content.endswith("\n"):
            env_file.write("\n")
        env_file.write(f"{line}\n")
    logger.info(message=f"Appended {key} to existing .env")


def copy_configuration_files() -> None:
    """
    Copy configuration files to the current working directory.

    This function copies the `config.yaml` file from the `avb_llm` package to
    the current working directory. If the file already exists, it is skipped.

    It also ensures a `.env` file exists in the current working directory
    containing the non-secret `AZURE_TOKEN_CREDENTIALS=dev` variable, creating
    the file if needed or appending the variable while preserving existing
    content.

    After copying, a message is logged with instructions to get started and a
    reminder to modify `config.yaml` based on the project requirements.
    """
    for filename in ["config.yaml"]:
        source: Traversable = files(package="avb_llm").joinpath(filename)
        dest: Path = Path.cwd() / filename
        if dest.exists():
            logger.warning(message=f"{dest} already exists, skipping.")
            continue
        logger.info(message=f"Copying {dest} to the current folder")
        shutil.copy(src=str(source), dst=dest)

    ensure_env_variable(key="AZURE_TOKEN_CREDENTIALS", value="dev")

    logger.info(
        message=(
            "Finished copying config.yaml to your current directory. "
            "To get started, pass the config.yaml to "
            "'initialize_agents' and ask a question:\n\n"
            "\033[3;96mfrom avb_llm import initialize_agents\n\n"
            'session = initialize_agents(config="config.yaml")\n'
            'response = session.run_sync("What is Asset Management?")\n\n'
            "print(response)\033[0m\n\n"
            "Change the config.yaml based on your project requirements."
        )
    )
