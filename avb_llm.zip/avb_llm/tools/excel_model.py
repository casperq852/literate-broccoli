from __future__ import annotations

from typing import TYPE_CHECKING, Any

from pydantic_ai import RunContext

from avb_llm.agents.helpers import ExcelDeps
from avb_llm.excel.helpers import build_excel_source
from avb_llm.excel.workbook.helpers import FilterCondition

if TYPE_CHECKING:
    from avb_llm.excel.workbook.workbook_controller import WorkbookController


def list_excel_workbooks(ctx: RunContext[ExcelDeps]) -> list[dict[str, Any]]:
    """
    List available workbook IDs, sheet names and formula support for each workbook.

    Args:
        ctx (RunContext[ExcelDeps]): The run context containing the Excel
            workspace controller.

    Returns:
        list[dict[str, Any]]: One entry per workbook, each containing
            ``workbook_id``, ``sheet_names`` and ``supports_formula_inspection``.
    """
    return [item.model_dump(mode="json") for item in ctx.deps.workspace_controller.list_workbooks()]


def list_excel_sheets(
    ctx: RunContext[ExcelDeps],
    workbook_reference: str,
) -> list[str]:
    """
    List the sheet names of one workbook in workbook order.

    This is a cheap lookup that lets an agent inspect the available sheets
    before committing to a full ``load_excel_sheet`` call.

    Args:
        ctx (RunContext[ExcelDeps]): The run context containing the Excel
            workspace controller.
        workbook_reference (str): A workbook ID, file stem or partial name.

    Returns:
        list[str]: The sheet names as they appear in the workbook.
    """
    controller: WorkbookController = ctx.deps.workspace_controller.get_workbook(workbook_reference=workbook_reference)
    return controller.sheet_names


def profile_excel_workbook(
    ctx: RunContext[ExcelDeps],
    workbook_reference: str,
) -> dict[str, Any]:
    """
    Return a bounded profile of the workbook to decide which sheets are relevant.

    The profile scans only a limited number of rows per sheet and does not
    return full sheet contents.

    Args:
        ctx (RunContext[ExcelDeps]): The run context containing the Excel
            workspace controller.
        workbook_reference (str): A workbook ID, file stem or partial name.

    Returns:
        dict[str, Any]: A profile with per-sheet dimensions, non-empty cell
            counts and sample values.
    """
    controller: WorkbookController = ctx.deps.workspace_controller.get_workbook(workbook_reference=workbook_reference)
    return controller.profile_workbook().model_dump(mode="json")


def load_excel_sheet(
    ctx: RunContext[ExcelDeps],
    workbook_reference: str,
    sheet_name: str,
) -> dict[str, Any]:
    """
    Load the complete sheet into the controller cache and return metadata only.

    Caching the sheet enables subsequent range, filter and search calls to
    operate on the in-memory DataFrame without re-reading the file.

    Args:
        ctx (RunContext[ExcelDeps]): The run context containing the Excel
            workspace controller.
        workbook_reference (str): A workbook ID, file stem or partial name.
        sheet_name (str): Name of the sheet to load.

    Returns:
        dict[str, Any]: Metadata describing the loaded sheet, including
            ``sheet_name``, ``row_count``, ``column_count`` and ``columns``.
    """
    controller: WorkbookController = ctx.deps.workspace_controller.get_workbook(workbook_reference=workbook_reference)
    return controller.load_complete_sheet(sheet_name).model_dump(mode="json")


def get_excel_range(
    ctx: RunContext[ExcelDeps],
    workbook_reference: str,
    sheet_name: str,
    start_row: int = 1,
    row_count: int = 10,
    start_column: int = 1,
    column_count: int = 15,
) -> dict[str, Any]:
    """
    Return one explicitly requested rectangular range from the cached sheet.

    Args:
        ctx (RunContext[ExcelDeps]): The run context containing the Excel
            workspace controller.
        workbook_reference (str): A workbook ID, file stem or partial name.
        sheet_name (str): Name of the sheet to query.
        start_row (int): 1-based row number of the top-left corner. Defaults
            to 1.
        row_count (int): Number of rows to return. Defaults to 10.
        start_column (int): 1-based column number of the top-left corner.
            Defaults to 1.
        column_count (int): Number of columns to return. Defaults to 15.

    Returns:
        dict[str, Any]: The requested data slice with start position,
            returned columns and truncation metadata.
    """
    controller: WorkbookController = ctx.deps.workspace_controller.get_workbook(workbook_reference=workbook_reference)
    range_result: dict[str, Any] = controller.get_range(
        sheet_name=sheet_name,
        start_row=start_row,
        row_count=row_count,
        start_column=start_column,
        column_count=column_count,
    ).model_dump(mode="json")
    end_row: int = start_row + row_count - 1
    end_column: int = start_column + column_count - 1
    ctx.deps.sources.append(
        build_excel_source(
            workbook_reference=workbook_reference,
            sheet_name=sheet_name,
            reference=f"rows {start_row}-{end_row}, columns {start_column}-{end_column}",
            detail="range read",
        )
    )
    return range_result


def filter_excel_rows(
    ctx: RunContext[ExcelDeps],
    workbook_reference: str,
    sheet_name: str,
    filters: list[FilterCondition],
    max_results: int = 20,
) -> dict[str, Any]:
    """
    Filter the cached sheet and return a bounded set of matching rows.

    All filter conditions are applied with a logical AND. Each returned row
    includes its 1-based Excel row number in an ``excel_row`` column, which
    filters may also target (for example to select a specific row range).

    Args:
        ctx (RunContext[ExcelDeps]): The run context containing the Excel
            workspace controller.
        workbook_reference (str): A workbook ID, file stem or partial name.
        sheet_name (str): Name of the sheet to filter.
        filters (list[FilterCondition]): The filter conditions to apply. May
            reference any sheet column or the synthetic ``excel_row`` column.
        max_results (int): Maximum number of matching rows to return. Defaults
            to 20.

    Returns:
        dict[str, Any]: The matching rows with total match count and truncation
            metadata.
    """
    controller: WorkbookController = ctx.deps.workspace_controller.get_workbook(workbook_reference=workbook_reference)
    filter_result: dict[str, Any] = controller.filter_rows(
        sheet_name=sheet_name,
        filters=filters,
        max_results=max_results,
    ).model_dump(mode="json")
    ctx.deps.sources.append(
        build_excel_source(
            workbook_reference=workbook_reference,
            sheet_name=sheet_name,
            reference="filter",
            detail=f"matched {filter_result.get('total_matches')} row(s)",
        )
    )
    return filter_result


def search_excel_rows(
    ctx: RunContext[ExcelDeps],
    workbook_reference: str,
    sheet_name: str,
    query: str,
    regex: bool = False,
    case_sensitive: bool = False,
    search_columns: list[str] | None = None,
    max_results: int = 20,
) -> dict[str, Any]:
    """
    Search the cached sheet and return a bounded set of matching rows with context.

    Each returned row includes its 1-based Excel row number in an
    ``excel_row`` column.

    Args:
        ctx (RunContext[ExcelDeps]): The run context containing the Excel
            workspace controller.
        workbook_reference (str): A workbook ID, file stem or partial name.
        sheet_name (str): Name of the sheet to search.
        query (str): The text or regular expression to look for.
        regex (bool): Whether to treat ``query`` as a regular expression.
            Defaults to False.
        case_sensitive (bool): Whether the match is case-sensitive. Defaults
            to False.
        search_columns (list[str] | None): Restrict the search to these
            columns. Searches all columns when None. Defaults to None.
        max_results (int): Maximum number of matching rows to return. Defaults
            to 20.

    Returns:
        dict[str, Any]: The matching rows with query, total match count and
            truncation metadata.
    """
    controller: WorkbookController = ctx.deps.workspace_controller.get_workbook(workbook_reference=workbook_reference)
    search_result: dict[str, Any] = controller.search_rows(
        sheet_name=sheet_name,
        query=query,
        regex=regex,
        case_sensitive=case_sensitive,
        search_columns=search_columns,
        max_results=max_results,
    ).model_dump(mode="json")
    ctx.deps.sources.append(
        build_excel_source(
            workbook_reference=workbook_reference,
            sheet_name=sheet_name,
            reference=f"search '{query}'",
            detail=f"matched {search_result.get('total_matches')} row(s)",
        )
    )
    return search_result


def explain_excel_cell(
    ctx: RunContext[ExcelDeps],
    workbook_reference: str,
    sheet_name: str,
    cell_reference: str,
) -> dict[str, Any]:
    """
    Explain a cell's cached value, raw formula and nearby labels.

    Args:
        ctx (RunContext[ExcelDeps]): The run context containing the Excel
            workspace controller.
        workbook_reference (str): A workbook ID, file stem or partial name.
        sheet_name (str): Name of the sheet that contains the cell.
        cell_reference (str): A1-style cell reference, e.g. ``"B25"``.

    Returns:
        dict[str, Any]: A compact description of the cell including its value,
            optional formula, data type and best-effort row and column labels.
    """
    controller: WorkbookController = ctx.deps.workspace_controller.get_workbook(workbook_reference=workbook_reference)
    explanation: dict[str, Any] = controller.explain_cell(
        sheet_name=sheet_name, cell_reference=cell_reference
    ).model_dump(mode="json")
    detail: str = f"value={explanation.get('value')}"
    if explanation.get("formula"):
        detail = f"{detail}, formula={explanation['formula']}"
    ctx.deps.sources.append(
        build_excel_source(
            workbook_reference=workbook_reference,
            sheet_name=sheet_name,
            reference=cell_reference,
            detail=detail,
        )
    )
    return explanation


def summarize_excel_columns(
    ctx: RunContext[ExcelDeps],
    workbook_reference: str,
    sheet_name: str,
    columns: list[str] | None = None,
) -> dict[str, Any]:
    """
    Return compact descriptive statistics and sample values for sheet columns.

    Args:
        ctx (RunContext[ExcelDeps]): The run context containing the Excel
            workspace controller.
        workbook_reference (str): A workbook ID, file stem or partial name.
        sheet_name (str): Name of the sheet to summarize.
        columns (list[str] | None): Column names to summarize. Summarizes all
            columns when None. Defaults to None.

    Returns:
        dict[str, Any]: Per-column statistics including counts, numeric range,
            distinct count and sample values.
    """
    controller: WorkbookController = ctx.deps.workspace_controller.get_workbook(workbook_reference=workbook_reference)
    return controller.summarize_columns(
        sheet_name=sheet_name,
        columns=columns,
    ).model_dump(mode="json")


def aggregate_excel_sheet(
    ctx: RunContext[ExcelDeps],
    workbook_reference: str,
    sheet_name: str,
    value_columns: list[str],
    operations: list[str],
    group_by: list[str] | None = None,
    filters: list[FilterCondition] | None = None,
    max_groups: int = 25,
) -> dict[str, Any]:
    """
    Aggregate sheet columns using a fixed safe operation set, with optional grouping.

    Supported operations are: ``sum``, ``mean``, ``min``, ``max``, ``std``,
    ``count`` and ``n_unique``.

    Args:
        ctx (RunContext[ExcelDeps]): The run context containing the Excel
            workspace controller.
        workbook_reference (str): A workbook ID, file stem or partial name.
        sheet_name (str): Name of the sheet to aggregate.
        value_columns (list[str]): Columns to aggregate.
        operations (list[str]): Operations to apply to each value column.
        group_by (list[str] | None): Columns to group by before aggregating.
            No grouping is applied when None. Defaults to None.
        filters (list[FilterCondition] | None): Optional filters applied before
            aggregation. Defaults to None.
        max_groups (int): Maximum number of output rows. Defaults to 25.

    Returns:
        dict[str, Any]: Aggregated rows with metric names, source row count
            and truncation metadata.
    """
    controller: WorkbookController = ctx.deps.workspace_controller.get_workbook(workbook_reference=workbook_reference)
    aggregation: dict[str, Any] = controller.aggregate(
        sheet_name=sheet_name,
        value_columns=value_columns,
        operations=operations,
        group_by=group_by,
        filters=filters,
        max_groups=max_groups,
    ).model_dump(mode="json")
    grouping: str = f" grouped by {group_by}" if group_by else ""
    ctx.deps.sources.append(
        build_excel_source(
            workbook_reference=workbook_reference,
            sheet_name=sheet_name,
            reference="aggregate",
            detail=f"{operations} of {value_columns}{grouping}",
        )
    )
    return aggregation


def search_excel_formulas(
    ctx: RunContext[ExcelDeps],
    workbook_reference: str,
    sheet_name: str | None = None,
    query: str | None = None,
    case_sensitive: bool = False,
    max_results: int = 50,
) -> dict[str, Any]:
    """
    Find formulas by sheet or formula text without returning all formulas at once.

    Args:
        ctx (RunContext[ExcelDeps]): The run context containing the Excel
            workspace controller.
        workbook_reference (str): A workbook ID, file stem or partial name.
        sheet_name (str | None): Restrict the search to this sheet. Searches
            all sheets when None. Defaults to None.
        query (str | None): Optional substring to match against formula text.
            Returns all formulas when None. Defaults to None.
        case_sensitive (bool): Whether the query match is case-sensitive.
            Defaults to False.
        max_results (int): Maximum number of formula cells to return. Defaults
            to 50.

    Returns:
        dict[str, Any]: The matching formula cells with a ``truncated`` flag.
    """
    controller: WorkbookController = ctx.deps.workspace_controller.get_workbook(workbook_reference=workbook_reference)
    formula_result: dict[str, Any] = controller.search_formulas(
        sheet_name=sheet_name,
        query=query,
        case_sensitive=case_sensitive,
        max_results=max_results,
    ).model_dump(mode="json")
    ctx.deps.sources.append(
        build_excel_source(
            workbook_reference=workbook_reference,
            sheet_name=sheet_name,
            reference=f"formula search '{query}'",
            detail=f"matched {len(formula_result.get('formulas', []))} formula cell(s)",
        )
    )
    return formula_result


def search_across_excel_workbooks(
    ctx: RunContext[ExcelDeps],
    query: str,
    regex: bool = False,
    case_sensitive: bool = False,
    max_rows_per_sheet: int = 5,
    max_hits: int = 20,
) -> dict[str, Any]:
    """
    Search every sheet of every workbook when the target workbook is unknown.

    Use this only for discovery: it loads and scans all sheets across the
    workspace. Once the relevant workbook and sheet are known, switch to the
    single-workbook tools (``search_excel_rows``, ``filter_excel_rows``) for
    focused, cheaper follow-up queries.

    Args:
        ctx (RunContext[ExcelDeps]): The run context containing the Excel
            workspace controller.
        query (str): The text or regular expression to look for.
        regex (bool): Whether to treat ``query`` as a regular expression.
            Defaults to False.
        case_sensitive (bool): Whether the match is case-sensitive. Defaults
            to False.
        max_rows_per_sheet (int): Maximum number of matching rows returned per
            sheet. Defaults to 5.
        max_hits (int): Maximum number of matching sheets returned across all
            workbooks. Defaults to 20.

    Returns:
        dict[str, Any]: The matching sheets grouped by workbook, each with its
            bounded rows, plus a ``truncated`` flag.
    """
    return ctx.deps.workspace_controller.search_workbooks(
        query=query,
        regex=regex,
        case_sensitive=case_sensitive,
        max_rows_per_sheet=max_rows_per_sheet,
        max_hits=max_hits,
    ).model_dump(mode="json")
