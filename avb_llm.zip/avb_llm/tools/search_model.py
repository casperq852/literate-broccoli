from __future__ import annotations

from typing import Any

from avb_core import get_logger
from avb_core.loggers import Logger
from azure.core.exceptions import HttpResponseError
from azure.search.documents import SearchItemPaged
from azure.search.documents.models import VectorizableTextQuery
from pydantic_ai import RunContext

from avb_llm.agents.helpers import SearchDeps
from avb_llm.agents.output_model import SearcherOutput

logger: Logger = get_logger(name=__name__, structured=True)


def vector_search_index(ctx: RunContext[SearchDeps], query: str) -> list[SearcherOutput]:
    """
    Perform a vector search on the Azure Search index using the provided query vector.

    Args:
        ctx (RunContext[SearchDeps]): The run context containing search dependencies,
            including the search client, top_k limit, and select fields.
        query (str): The search query string to be used for searching the index.

    Returns:
        list[SearcherOutput]: The vector search results as SearcherOutput items.
    """
    vector_query: VectorizableTextQuery = VectorizableTextQuery(
        text=query,
        k_nearest_neighbors=ctx.deps.top_k,
        fields="contentVector",
    )

    outputs: list[SearcherOutput] = []
    try:
        vector_results: SearchItemPaged[dict[Any, Any]] = ctx.deps.search_client.search(
            vector_queries=[vector_query],
            select=ctx.deps.select_fields,
        )
        for result in vector_results:
            raw: dict[str, Any] = dict(result)  # bevat @search.score + content
            ctx.deps.sources.append(raw)  # programmatische capture
            outputs.append(
                SearcherOutput(
                    content=raw.get("content", ""),
                    metadata={field: raw.get(field) for field in ctx.deps.select_fields if field != "content"},
                )
            )
    except HttpResponseError as exc:
        index_name: Any = getattr(ctx.deps.search_client, "index_name", "<unknown>")
        logger.warning(
            message=(
                f"Vector search on index '{index_name}' failed "
                f"(status {exc.status_code}): {exc.message}. Returning no results."
            )
        )
        return []
    return outputs
