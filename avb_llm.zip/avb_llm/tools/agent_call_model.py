from __future__ import annotations

from pydantic import BaseModel
from pydantic_ai import RunContext
from pydantic_ai.run import AgentRunResult

from avb_llm.agents.helpers import OrchestratorDeps
from avb_llm.agents.output_model import SearcherOutput, ValidatorOutput


async def call_summarizer_agent(ctx: RunContext[OrchestratorDeps], instructions: str) -> str:
    """
    Call the summarizer agent to summarize, rewrite or clarify content
    into a clean, user-friendly response. Use this tool whenever a final
    answer needs to be presented clearly — e.g. after retrieving search
    results, or when the user asks for an explanation or rewrite.

    Args:
        instructions (str): A clear instruction describing what to produce,
            e.g. 'Summarize the following in bullet points: ...' or
            'Rewrite this in plain English: ...'.

    Returns:
        str: The chat agent's response along with its reasoning summary.
    """
    result: AgentRunResult[str] = await ctx.deps.agents["summarizer"].run(
        user_prompt=instructions, deps=ctx.deps.agent_deps["summarizer"]
    )
    return f"{result.output}"


async def call_search_agent(ctx: RunContext[OrchestratorDeps], search_index_query: str) -> str:
    """
    Call the search agent when the user's request requires retrieving facts, documents,
    or data from the Azure AI Search index. Suitable for: look-ups, fact-finding,
    question answering over indexed content, or any task where grounding in
    retrieved documents is needed.

    Args:
        search_index_query (str): A concise, keyword-rich query string optimised
            for searching the index (not a full sentence if avoidable).

    Returns:
        str: The search agent's response along with its reasoning summary.
    """
    result: AgentRunResult[SearcherOutput] = await ctx.deps.agents["index_searcher"].run(
        user_prompt=search_index_query, deps=ctx.deps.agent_deps["index_searcher"]
    )
    return f"{result.output}"


async def call_validator_agent(ctx: RunContext[OrchestratorDeps], question: str, answer: str) -> str:
    """
    Call the validator agent as a final quality-check step before returning an answer to the user.
    The validator agent independently evaluates whether the proposed answer correctly
    and completely addresses the user's question. Call this tool after a final answer
    has been composed but before delivering it. Only call when the question is considered
    complex enough to require an extra step.

    Args:
        question (str): The original question asked by the user.
        answer (str): The proposed final answer to be validated.

    Returns:
        str: The validator agent's verdict and reasoning summary, indicating whether
            the answer is acceptable or should be revised.
    """
    prompt: str = f"The user's question: {question}. The proposed answer: {answer}"
    result: AgentRunResult[ValidatorOutput] = await ctx.deps.agents["validator"].run(
        user_prompt=prompt, deps=ctx.deps.agent_deps["validator"]
    )
    return f"{result.output}"


async def call_excel_agent(ctx: RunContext[OrchestratorDeps], instructions: str) -> str:
    """
    Call the Excel agent to analyze, summarize, or answer questions about
    the contents of an Excel workbook. Use this tool when the user asks
    for insights, explanations, or summaries of data in an Excel file.

    Args:
        instructions (str): A clear instruction describing what to produce,
            e.g. 'Summarize the following sheet: ...' or
            'Explain the trends in this data: ...'.

    Returns:
        str: The Excel agent's response along with its reasoning summary.
    """
    result: AgentRunResult[str] = await ctx.deps.agents["excel_analyzer"].run(
        user_prompt=instructions, deps=ctx.deps.agent_deps["excel_analyzer"]
    )
    return f"{result.output}"


async def call_field_finder_agent(ctx: RunContext[OrchestratorDeps], instructions: str) -> str:
    """
    Call the field finder agent to extract a fixed set of fields from the given
    content and return them as a structured object. Any field that cannot be
    determined is returned as null. Use this tool when the user needs specific,
    named values pulled out of text or search results.

    Args:
        instructions (str): A clear instruction describing which fields to
            extract and from which content.

    Returns:
        str: The field finder agent's structured output rendered as a string.
    """
    result: AgentRunResult[BaseModel] = await ctx.deps.agents["field_finder"].run(
        user_prompt=instructions, deps=ctx.deps.agent_deps["field_finder"]
    )
    return f"{result.output}"
