from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Generic, TypeVar

from avb_core import get_logger
from avb_core.loggers import Logger
from pydantic_ai.agent import Agent
from pydantic_ai.messages import ModelResponse, TextPart, ThinkingPart, ToolCallPart
from pydantic_ai.run import AgentRunResult

from avb_llm.agents.helpers import BaseDeps
from avb_llm.session.helpers import build_prompt_parts

logger: Logger = get_logger(name=__name__, structured=True)

OutputT = TypeVar("OutputT")


class AgentSessionModel(Generic[OutputT]):
    def __init__(self, agent: Agent[Any, OutputT], deps: BaseDeps, debug: bool = False) -> None:
        """
        Initialize the agent session.

        Args:
            agent (Agent[Any, OutputT]): The orchestrator agent to run.
            deps (BaseDeps): The dependencies passed to the agent on each run.
            debug (bool): Whether to include the reasoning summary. Defaults to False.
        """
        self.agent: Agent[Any, OutputT] = agent
        self.deps: BaseDeps = deps
        self.debug: bool = debug
        self._message_history: list[Any] = []

    def run_cli_chat(self) -> None:
        """
        Run a synchronous interactive CLI chat loop.

        Prompts the user for input and prints the assistant's answer until the
        user types 'exit', 'quit' or 'q'.
        """
        logger.info(message="CLI chat started. Type 'exit', 'quit', or 'q' to stop.")
        while True:
            try:
                question: str = input("\nYou: ").strip()
            except KeyboardInterrupt:
                logger.info(message="Exiting chat.")
                break

            if question.lower() in ["exit", "quit", "q"]:
                logger.info(message="Exiting chat.")
                break

            if not question:
                continue

            answer: OutputT | dict[str, Any] | str = self.ask_sync(question=question)
            logger.info(message=f"Assistant: {answer}")

    def extract_agent_thinking(self, result: AgentRunResult[Any]) -> dict[str, list[str]] | None:
        """
        Extract the reasoning, text and tool-call parts from an agent run result.

        Args:
            result (AgentRunResult[Any]): The result returned by an agent run.

        Returns:
            dict[str, list[str]] | None: A dictionary with 'thinking_parts',
                'text_parts' and 'tool_calls' keys, or None when no content was found.
        """
        thinking_parts: list[str] = []
        text_parts: list[str] = []
        tool_calls: list[Any] = []
        for message in result.new_messages():
            if isinstance(message, ModelResponse):
                for part in message.parts:
                    if isinstance(part, ThinkingPart) and part.has_content():
                        content: str = part.content
                        thinking_parts.append(content)
                    elif isinstance(part, TextPart) and part.has_content():
                        text_content: str = part.content
                        text_parts.append(text_content)
                    elif isinstance(part, ToolCallPart):
                        tool_calls.append({"tool_name": part.tool_name, "args": part.args})
                    else:
                        continue
        if thinking_parts or text_parts or tool_calls:
            return {"thinking_parts": thinking_parts, "text_parts": text_parts, "tool_calls": tool_calls}
        return None

    def ask_sync(
        self, question: str, structured: bool = False, file_paths: list[Path] = []
    ) -> OutputT | dict[str, Any] | str:
        """
        Ask the agent a question synchronously and update the message history.

        Args:
            question (str): The question to send to the agent.
            structured (bool): Whether to return a structured response. Defaults to False.
            file_paths (list[Path]): Optional list of file paths to include in the prompt.

        Returns:
            OutputT | dict[str, Any] | str: The agent answer typed as the agent's output type,
                a structured dict, or a reasoning-summary string in debug mode.
        """
        result: AgentRunResult[OutputT] = self.agent.run_sync(
            user_prompt=[question, *[build_prompt_parts(Path(file)) for file in file_paths]],
            deps=self.deps,
            message_history=self._message_history,
        )
        self._message_history = result.all_messages()
        if not self.debug:
            if structured:
                return {
                    "answer": result.output,
                    "thinking_parts": [],
                    "text_parts": [],
                    "tool_calls": [],
                }
            return result.output

        thought_process: dict[str, list[Any]] | None = self.extract_agent_thinking(result)

        if structured:
            return {
                "answer": result.output,
                "thinking_parts": thought_process["thinking_parts"] if thought_process else [],
                "text_parts": thought_process["text_parts"] if thought_process else [],
                "tool_calls": thought_process["tool_calls"] if thought_process else [],
            }

        if thought_process is not None:
            thinking_parts: list[str] = thought_process["thinking_parts"]
            text_parts: list[str] = thought_process["text_parts"]
            tool_calls: list[Any] = thought_process["tool_calls"]
            return (
                f"{result.output}\n\n"
                f"---\n"
                f"Reasoning summary:\n\n"
                f"Thinking parts:\n{thinking_parts}\n\n"
                f"Text parts:\n{text_parts}\n\n"
                f"Tool calls:\n{tool_calls}"
            )
        return f"{result.output}\n\n---\nReasoning summary not returned by the model/provider"

    async def ask_async(
        self, question: str, structured: bool = False, file_paths: list[Path] = []
    ) -> OutputT | dict[str, Any] | str:
        """
        Ask the agent a question asynchronously and update the message history.

        Args:
            question (str): The question to send to the agent.
            structured (bool): Whether to return a structured response. Defaults to False.

        Returns:
            OutputT | dict[str, Any] | str: The agent answer typed as the agent's output type,
                a structured dict, or a reasoning-summary string in debug mode.
        """
        result: AgentRunResult[OutputT] = await self.agent.run(
            user_prompt=[question, *[build_prompt_parts(Path(file)) for file in file_paths]],
            deps=self.deps,
            message_history=self._message_history,
        )
        self._message_history = result.all_messages()
        if not self.debug:
            if structured:
                return {
                    "answer": result.output,
                    "thinking_parts": [],
                    "text_parts": [],
                    "tool_calls": [],
                }
            return result.output

        thought_process: dict[str, list[Any]] | None = self.extract_agent_thinking(result)

        if structured:
            return {
                "answer": result.output,
                "thinking_parts": thought_process["thinking_parts"] if thought_process else [],
                "text_parts": thought_process["text_parts"] if thought_process else [],
                "tool_calls": thought_process["tool_calls"] if thought_process else [],
            }

        if thought_process is not None:
            thinking_parts: list[str] = thought_process["thinking_parts"]
            text_parts: list[str] = thought_process["text_parts"]
            tool_calls: list[Any] = thought_process["tool_calls"]
            return (
                f"{result.output}\n\n"
                f"---\n"
                f"Reasoning summary:\n\n"
                f"Thinking parts:\n{thinking_parts}\n\n"
                f"Text parts:\n{text_parts}\n\n"
                f"Tool calls:\n{tool_calls}"
            )
        return f"{result.output}\n\n---\nReasoning summary not returned by the model/provider"

    async def run_cli_chat_async(self) -> None:
        """
        Run an asynchronous interactive CLI chat loop.

        Prompts the user for input and prints the assistant's answer until the
        user types 'exit', 'quit' or 'q'.
        """
        logger.info(message="CLI chat started. Type 'exit', 'quit', or 'q' to stop.")
        while True:
            try:
                question: str = input("\nYou: ").strip()
            except KeyboardInterrupt:
                logger.info(message="Exiting chat.")
                break

            if question.lower() in ["exit", "quit", "q"]:
                logger.info(message="Exiting chat.")
                break

            if not question:
                continue

            answer: OutputT | dict[str, Any] | str = await self.ask_async(question=question)
            logger.info(message=f"Assistant: {answer}")

    def run_cli_chat_asyncio(self) -> None:
        """
        Run the asynchronous CLI chat loop using asyncio.run.
        """
        asyncio.run(main=self.run_cli_chat_async())
