from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

from pydantic_ai import BinaryContent

SUPPORTED_MEDIA_TYPES: dict[str, str] = {
    ".pdf": "application/pdf",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".wav": "audio/wav",
    ".mp3": "audio/mpeg",
    ".ogg": "audio/ogg",
    ".flac": "audio/flac",
    ".aiff": "audio/aiff",
    ".aac": "audio/aac",
    ".mkv": "video/x-matroska",
    ".mov": "video/quicktime",
    ".mp4": "video/mp4",
    ".webm": "video/webm",
    ".flv": "video/x-flv",
    ".mpeg": "video/mpeg",
    ".wmv": "video/x-ms-wmv",
    ".3gp": "video/3gpp",
}


TEXT_MEDIA_TYPES: dict[str, str] = {
    ".txt": "text/plain",
    ".csv": "text/csv",
    ".md": "text/markdown",
    ".html": "text/html",
    ".htm": "text/html",
}


PDF_CONVERTIBLE_TYPES: set[str] = {".docx", ".doc", ".pptx", ".ppt"}

LIBREOFFICE_TIMEOUT_SECONDS: int = 120


def convert_to_pdf(file_path: Path) -> bytes:
    """
    Convert an Office document to PDF bytes using headless LibreOffice.

    Args:
        file_path (Path): Path to the document to convert.

    Returns:
        bytes: The rendered PDF content.

    Raises:
        RuntimeError: If LibreOffice is unavailable, the conversion fails or
            times out, or no PDF is produced.
    """
    soffice: str | None = shutil.which("soffice") or shutil.which("libreoffice")
    if soffice is None:
        raise RuntimeError(
            f"LibreOffice ('soffice') is required to convert '{file_path.suffix}' files to PDF "
            "but was not found on the system."
        )

    with tempfile.TemporaryDirectory() as tmp_dir:
        profile_dir: Path = Path(tmp_dir) / "loprofile"
        output_dir: Path = Path(tmp_dir) / "out"
        output_dir.mkdir()

        try:
            _ = subprocess.run(  # noqa: S603
                [
                    soffice,
                    "--headless",
                    f"-env:UserInstallation=file://{profile_dir}",
                    "--convert-to",
                    "pdf",
                    "--outdir",
                    str(output_dir),
                    str(file_path),
                ],
                check=True,
                capture_output=True,
                timeout=LIBREOFFICE_TIMEOUT_SECONDS,
            )
        except subprocess.CalledProcessError as exc:
            raise RuntimeError(
                f"Failed to convert '{file_path.name}' to PDF: {exc.stderr.decode(errors='ignore')}"
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError(f"Timed out converting '{file_path.name}' to PDF.") from exc

        pdf_path: Path = output_dir / f"{file_path.stem}.pdf"
        if not pdf_path.exists():
            raise RuntimeError(f"No PDF was produced when converting '{file_path.name}'.")
        return pdf_path.read_bytes()


def build_prompt_parts(file_path: Path) -> str | BinaryContent:
    """
    Return an inlined text string for text files, or BinaryContent for binary files.

    Office documents (.docx, .doc, .pptx, .ppt) are converted to PDF first, since
    the model accepts PDF reliably but not these formats natively.
    """
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    suffix: str = file_path.suffix.lower()

    if suffix in TEXT_MEDIA_TYPES:
        return f"--- File: {file_path.name} ---\n{file_path.read_text(encoding='utf-8')}"

    if suffix in PDF_CONVERTIBLE_TYPES:
        return BinaryContent(data=convert_to_pdf(file_path), media_type="application/pdf")

    media_type: str | None = SUPPORTED_MEDIA_TYPES.get(suffix)
    if media_type is None:
        raise ValueError(f"Unsupported file type '{suffix}' for file: {file_path}")

    return BinaryContent(data=file_path.read_bytes(), media_type=media_type)
