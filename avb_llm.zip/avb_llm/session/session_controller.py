from collections.abc import Iterable
from pathlib import Path
from typing import Any

import logfire
from avb_core import get_logger
from avb_core.loggers import Logger
from opentelemetry.sdk.trace import ReadableSpan, SpanProcessor
from opentelemetry.trace import StatusCode
from pydantic_ai.agent import Agent

from avb_llm.agents.agents_model import CATEGORY_REGISTRY, AgentCategory
from avb_llm.agents.base_agent_controller import BaseAgentController
from avb_llm.agents.base_agent_model import AppConfig, BaseAgentConfigModel
from avb_llm.agents.helpers import BaseDeps, ExcelDeps, OrchestratorDeps, SearchDeps
from avb_llm.clients import AzureAISearchClient
from avb_llm.excel.workspace_controller import ExcelWorkspaceController
from avb_llm.helpers import read_yaml_file
from avb_llm.pipelines import AgentInitPipeline
from avb_llm.session.session_model import AgentSessionModel

DEFAULT_APP_CONFIG_PATH: Path = Path(__file__).resolve().parent.parent / "app_config.yaml"
DEFAULT_CONFIG_PATH: Path = Path(__file__).resolve().parent.parent / "config.yaml"
DEFAULT_INDEX_NAME: str = "sr_pim_documentation"
DEAFAULT_SELECT_FIELDS: list[str] = ["content", "title", "page", "path"]


logger: Logger = get_logger(name=__name__, structured=True)


class _LogfireToAvbCoreSpanProcessor(SpanProcessor):
    """Forward logfire / OpenTelemetry spans to the avb_core structured logger.

    Routes PydanticAI's logfire instrumentation through the same structured
    logging pipeline as the rest of the application instead of logfire's own
    console output, so all telemetry shares one consistent format.
    """

    def __init__(self, structured_logger: Logger) -> None:
        """
        Initialize the span processor.

        Args:
            structured_logger (Logger): The avb_core logger to forward spans to.
        """
        self._logger: Logger = structured_logger

    def on_end(self, span: ReadableSpan) -> None:
        """
        Emit a finished span as a structured log record.

        Args:
            span (ReadableSpan): The completed span to log.
        """
        duration_ms: float = (
            (span.end_time - span.start_time) / 1_000_000
            if span.end_time is not None and span.start_time is not None
            else 0.0
        )
        message: str = f"logfire span: {span.name} ({duration_ms:.1f}ms)"
        if span.status.status_code is StatusCode.ERROR:
            self._logger.error(message=f"{message} - {span.status.description or 'error'}")
        else:
            self._logger.info(message=message)


class AgentSessionController:
    def __init__(self) -> None:
        """Initialize the session controller."""

    # Maybe later self.usecase_config for example (to specialize builder for usecase)

    def build_from_profile(
        self,
        profile_name: str,
        debug: bool = False,
        excel_paths: Iterable[str | Path] | None = None,
        config_path: str | Path = DEFAULT_CONFIG_PATH,
        extra_tools: dict[str, list] | None = None,
        sources: list[dict[str, Any]] | None = None,
    ) -> AgentSessionModel:
        """
        Build an AgentSessionModel based on a profile defined in config.yaml.

        Each profile lists the sub-agents the orchestrator may delegate to.
        An empty list means the orchestrator searches and answers directly.

        Args:
            profile_name (str): Name of the profile to build, as defined
                under ``profiles`` in config.yaml.
            debug (bool): Whether to run the session in debug mode.
            excel_paths (Iterable[str | Path] | None): Paths to the Excel
                workbooks, required when the profile contains a sub-agent
                that needs Excel deps. Defaults to None.

        Returns:
            AgentSessionModel: The assembled session with its orchestrator
                agent and dependencies.

        Raises:
            ValueError: If the profile is unknown, contains unknown
                sub-agents, or needs Excel deps while no excel_paths is given.
        """
        config: dict[str, Any] = read_yaml_file(location=config_path)
        shared_sources: list[dict[str, Any]] = sources if sources is not None else []

        if profile_name not in config["profiles"]:
            raise ValueError(f"Unknown profile '{profile_name}'. " f"Allowed profiles: {sorted(config['profiles'])}")

        sub_agent_names: list[str] = config["profiles"][profile_name].get("sub_agents", [])

        force_orchestrator: bool = "orchestrator" in sub_agent_names
        sub_agent_names = [name for name in sub_agent_names if name != "orchestrator"]

        extra_agent_configs: dict[str, dict] = config.get("extra_agent_configs", {})

        for extra_name, extra_cfg in extra_agent_configs.items():
            extra_type: str | None = extra_cfg.get("type")
            if extra_type not in CATEGORY_REGISTRY:
                raise ValueError(
                    f"Extra agent '{extra_name}' has unknown type '{extra_type}'. "
                    f"Allowed types: {sorted(CATEGORY_REGISTRY)}"
                )

        known_agents: set[str] = set(CATEGORY_REGISTRY) | set(extra_agent_configs)
        unknown: list[str] = [n for n in sub_agent_names if n not in known_agents]
        if unknown:
            raise ValueError(
                f"Profile '{profile_name}' contains unknown sub-agents: {unknown}. "
                f"Allowed categories: {sorted(known_agents)}"
            )

        if excel_paths is None:
            excluded: list[str] = [
                agent
                for agent in sub_agent_names
                if CATEGORY_REGISTRY[extra_agent_configs.get(agent, {}).get("type", agent)].needs_excel_deps
            ]
            if excluded:
                logger.warning(message=f"No Excel files provided. Excluding agent(s) from pipeline: {excluded}.")
            sub_agent_names = [agent for agent in sub_agent_names if agent not in excluded]
        if extra_tools:
            allowed_targets: set[str] = {"orchestrator", *sub_agent_names}
            invalid: list[str] = [name for name in extra_tools if name not in allowed_targets]
            if invalid:
                raise ValueError(
                    f"Cannot add tools to {invalid}: not part of profile '{profile_name}'. "
                    f"Allowed agents: {sorted(allowed_targets)}"
                )

        _ = logfire.configure(
            send_to_logfire=False,
            console=False,
            additional_span_processors=[_LogfireToAvbCoreSpanProcessor(structured_logger=logger)],
        )
        logfire.instrument_pydantic_ai()

        app_config: AppConfig = AppConfig.from_yaml(path=DEFAULT_APP_CONFIG_PATH)

        for extra_name, extra_cfg in extra_agent_configs.items():
            app_config.add_agent_config(name=extra_name, config=extra_cfg)

        agent_overrides: dict[str, dict[str, Any]] = config.get("agent_overrides", {})
        for name, overrides in agent_overrides.items():
            existing: BaseAgentConfigModel | None = app_config.agent_configs.get(name)
            if existing is None:
                raise ValueError(
                    f"agent_overrides references unknown agent '{name}'. "
                    f"Known agents: {sorted(app_config.agent_configs)}"
                )
            app_config.agent_configs[name] = existing.model_copy(update=overrides)
        pipeline: AgentInitPipeline = AgentInitPipeline(app_config=app_config)

        if not sub_agent_names:
            factories, agents = pipeline.build_agent_pipeline(
                agent_names=["orchestrator"], sub_agent_names=[], extra_tools=extra_tools
            )
            search_deps: SearchDeps = SearchDeps(
                search_client=AzureAISearchClient(
                    endpoint=factories["orchestrator"].agent_config.search_endpoint,
                    index_name=factories["orchestrator"].agent_config.index_name or DEFAULT_INDEX_NAME,
                ),
                top_k=8,
                select_fields=factories["orchestrator"].agent_config.select_fields or DEAFAULT_SELECT_FIELDS,
                sources=shared_sources,
            )
            return AgentSessionModel(
                agent=agents["orchestrator"],
                deps=search_deps,
                debug=debug,
            )
        if len(sub_agent_names) == 1 and not force_orchestrator:
            agent_name: str = sub_agent_names[0]
            factories, agents = pipeline.build_agent_pipeline(
                agent_names=[agent_name], sub_agent_names=[], extra_tools=extra_tools
            )
            category: AgentCategory = CATEGORY_REGISTRY[factories[agent_name].agent_config.type]
            if category.needs_search_deps:
                single_deps: BaseDeps = SearchDeps(
                    search_client=AzureAISearchClient(
                        endpoint=factories[agent_name].agent_config.search_endpoint,
                        index_name=factories[agent_name].agent_config.index_name or DEFAULT_INDEX_NAME,
                    ),
                    top_k=8,
                    select_fields=factories["orchestrator"].agent_config.select_fields or DEAFAULT_SELECT_FIELDS,
                    sources=shared_sources,
                )
            elif category.needs_excel_deps:
                single_deps = ExcelDeps(
                    workspace_controller=ExcelWorkspaceController(file_paths=excel_paths),
                    sources=shared_sources,
                )
            else:
                single_deps = BaseDeps()
            return AgentSessionModel(agent=agents[agent_name], deps=single_deps, debug=debug)

        names: list[str] = ["orchestrator", *sub_agent_names]
        factories, agents = pipeline.build_agent_pipeline(
            agent_names=names, sub_agent_names=sub_agent_names, extra_tools=extra_tools
        )

        orchestrator_deps: OrchestratorDeps = self._build_orchestrator_deps(
            sub_agent_names=sub_agent_names,
            agents=agents,
            factories=factories,
            excel_paths=excel_paths,
            sources=shared_sources,
        )

        return AgentSessionModel(
            agent=agents["orchestrator"],
            deps=orchestrator_deps,
            debug=debug,
        )

    def _build_orchestrator_deps(
        self,
        sub_agent_names: list[str],
        agents: dict[str, Agent[Any, Any]],
        factories: dict[str, BaseAgentController],
        excel_paths: Iterable[str | Path] | None,
        sources: list[dict[str, Any]],
    ) -> OrchestratorDeps:
        """
        Assemble the orchestrator dependencies for the given sub-agents.

        Wires each sub-agent into the orchestrator dependencies together with the
        search or Excel dependencies required by its category.

        Args:
            sub_agent_names (list[str]): Names of the sub-agents to wire in.
            agents (dict): The built agents keyed by name.
            factories (dict): The agent controllers keyed by name.
            excel_paths (Iterable[str | Path] | None): Optional Excel workbook paths to make available.
            profile_name (str): Name of the active profile.

        Returns:
            OrchestratorDeps: The assembled orchestrator dependencies.
        """
        orchestrator_deps: OrchestratorDeps = OrchestratorDeps()
        for name in sub_agent_names:
            orchestrator_deps.agents[name] = agents[name]
            category: AgentCategory = CATEGORY_REGISTRY[factories[name].agent_config.type]
            if category.needs_search_deps:
                orchestrator_deps.agent_deps[name] = SearchDeps(
                    search_client=AzureAISearchClient(
                        endpoint=factories["orchestrator"].agent_config.search_endpoint,
                        index_name=factories[name].agent_config.index_name or DEFAULT_INDEX_NAME,
                    ),
                    top_k=8,
                    select_fields=factories["orchestrator"].agent_config.select_fields or DEAFAULT_SELECT_FIELDS,
                    sources=sources,
                )
            elif category.needs_excel_deps:
                orchestrator_deps.agent_deps[name] = ExcelDeps(
                    workspace_controller=ExcelWorkspaceController(file_paths=excel_paths),
                    sources=sources,
                )
            else:
                orchestrator_deps.agent_deps[name] = BaseDeps()
        return orchestrator_deps
