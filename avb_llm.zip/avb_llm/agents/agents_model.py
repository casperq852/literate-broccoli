from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from pydantic_ai import FunctionToolset, RunContext
from pydantic_ai.agent import AgentRunResult

from avb_llm.agents.base_agent_controller import BaseAgentController
from avb_llm.agents.base_agent_model import BaseAgentConfigModel
from avb_llm.agents.helpers import BaseDeps, ExcelDeps, OrchestratorDeps, SearchDeps
from avb_llm.tools.agent_call_model import (
    call_excel_agent,
    call_field_finder_agent,
    call_search_agent,
    call_summarizer_agent,
    call_validator_agent,
)
from avb_llm.tools.excel_model import (
    aggregate_excel_sheet,
    explain_excel_cell,
    filter_excel_rows,
    get_excel_range,
    list_excel_sheets,
    list_excel_workbooks,
    load_excel_sheet,
    profile_excel_workbook,
    search_across_excel_workbooks,
    search_excel_formulas,
    search_excel_rows,
    summarize_excel_columns,
)
from avb_llm.tools.search_model import vector_search_index


def make_delegation_tool(
    agent_name: str, agent_instructions: str
) -> Callable[[RunContext[OrchestratorDeps], str], Awaitable[str]]:
    """Create a delegation tool that routes the orchestrator's request to a named sub-agent.

    Used for user-defined agents (declared via ``extra_agent_configs``) that reuse an
    existing type but have a custom name, so they have no hand-written call-tool in
    ``CATEGORY_REGISTRY``.

    Args:
        agent_name (str): The sub-agent name as used in ``OrchestratorDeps.agents``.
        agent_instructions (str): The agent's own instructions, surfaced in the
            tool docstring so the orchestrator knows when to delegate to it.

    Returns:
        Callable[[RunContext[OrchestratorDeps], str], Awaitable[str]]: An async
            call-tool named ``call_<agent_name>``.
    """

    async def _call(ctx: RunContext[OrchestratorDeps], instructions: str) -> str:
        """
        Delegate the given instructions to the named sub-agent and return its output.

        Args:
            ctx (RunContext[OrchestratorDeps]): The orchestrator run context holding sub-agent deps.
            instructions (str): The task instructions to pass to the sub-agent.

        Returns:
            str: The sub-agent's output rendered as a string.
        """
        result: AgentRunResult[Any] = await ctx.deps.agents[agent_name].run(
            user_prompt=instructions, deps=ctx.deps.agent_deps[agent_name]
        )
        return f"{result.output}"

    _call.__name__ = f"call_{agent_name}"
    _call.__doc__ = (
        f"Delegate a task to the '{agent_name}' agent.\n\n"
        f"This agent specializes in: {agent_instructions}\n\n"
        f"Args:\n    instructions (str): ..."
    )
    return _call


class SummarizerAgentController(BaseAgentController):
    """Controller for the summarizer agent, which rewrites and condenses text."""

    def __init__(self, config: BaseAgentConfigModel) -> None:
        """
        Initialize the summarizer agent controller.

        Args:
            config (BaseAgentConfigModel): The agent configuration.
        """
        super().__init__(config=config)


class SearchAgentController(BaseAgentController):
    """Controller for the search agent, which queries an Azure AI Search index."""

    def __init__(self, config: BaseAgentConfigModel) -> None:
        """
        Initialize the search agent controller and wire its search toolset.

        Args:
            config (BaseAgentConfigModel): The agent configuration.
        """
        super().__init__(config=config)
        self.deps_type: type[BaseDeps] = SearchDeps
        self.toolsets: list[Any] = [
            FunctionToolset[SearchDeps](
                tools=[vector_search_index],
                instructions="""
                This toolset provides access to an Azure AI Search Index.
                Use `vector_search_index` to query the index with a search term and optional filters.
            """,
            )
        ]


class OrchestratorAgentController(BaseAgentController):
    """Controller for the orchestrator agent, which delegates to specialist agents."""

    def __init__(
        self,
        config: BaseAgentConfigModel,
        sub_agent_names: list[str] | None = None,
        call_tools: list[Any] | None = None,
    ) -> None:
        """
        Initialize the orchestrator agent controller.

        When sub-agents are provided, the orchestrator is wired with delegation
        tools for each of them. Otherwise it falls back to searching and
        answering directly through the search toolset.

        Args:
            config (BaseAgentConfigModel): The agent configuration.
            sub_agent_names (list[str] | None): Names of the sub-agents the
                orchestrator may delegate to. Defaults to None.
        """
        super().__init__(config=config)
        sub_agent_names = sub_agent_names or []

        if sub_agent_names:
            self.deps_type: type[BaseDeps] = OrchestratorDeps
            tools: list[Any] = (
                call_tools if call_tools is not None else [CATEGORY_REGISTRY[name].call_tool for name in sub_agent_names]
            )
            tool_lines: str = "\n".join(
                f"                    - {tool.__name__}: {(tool.__doc__ or '').strip().splitlines()[0]}" for tool in tools
            )
            self.toolsets: list[Any] = [
                FunctionToolset[OrchestratorDeps](
                    tools=tools,
                    instructions=(
                        "Use these tools to delegate work to specialist agents.\n"
                        f"{tool_lines}\n"
                        "Only the tools listed here are available to you. Base your plan on these."
                    ),
                )
            ]
        else:
            self.deps_type = SearchDeps
            self.toolsets = [
                FunctionToolset[SearchDeps](
                    tools=[vector_search_index],
                    instructions="""
                    This toolset provides access to an Azure AI Search Index.
                    Use `vector_search_index` to query the index with a search term and optional filters.
                """,
                )
            ]


class ValidatorAgentController(BaseAgentController):
    """Controller for the validator agent, which checks whether an answer is sound."""

    def __init__(self, config: BaseAgentConfigModel) -> None:
        """
        Initialize the validator agent controller.

        Args:
            config (BaseAgentConfigModel): The agent configuration.
        """
        super().__init__(config=config)


class ExcelAnalyzerAgentController(BaseAgentController):
    """Controller for the Excel analyzer agent, which inspects Excel workbooks."""

    def __init__(self, config: BaseAgentConfigModel) -> None:
        """
        Initialize the Excel analyzer agent controller and wire its Excel toolset.

        Args:
            config (BaseAgentConfigModel): The agent configuration.
        """
        super().__init__(config=config)
        self.deps_type: type[BaseDeps] = ExcelDeps
        self.toolsets: list[Any] = [
            FunctionToolset[ExcelDeps](
                tools=[
                    list_excel_workbooks,
                    list_excel_sheets,
                    profile_excel_workbook,
                    load_excel_sheet,
                    get_excel_range,
                    filter_excel_rows,
                    search_excel_rows,
                    search_across_excel_workbooks,
                    explain_excel_cell,
                    summarize_excel_columns,
                    aggregate_excel_sheet,
                    search_excel_formulas,
                ],
                instructions="""
                Use the Excel tools in the following way:

                1. Resolve the workbook with `list_excel_workbooks` before assuming an exact
                workbook filename, and use `list_excel_sheets` to see the sheets of a chosen
                workbook. When you do not yet know which workbook holds the answer, use
                `search_across_excel_workbooks` once to locate it, then continue with the
                single-workbook tools.
                2. Use `profile_excel_workbook` only to identify relevant sheets and understand
                their basic structure. A workbook profile is sampled and must never be used
                as the data source for a calculation or as proof that a value is absent.
                3. Use `load_excel_sheet` to make the complete sheet available in the internal
                Polars cache. The tool intentionally returns metadata instead of the full
                DataFrame.
                4. Use `search_excel_rows` for textual discovery across the complete sheet.
                5. Use `filter_excel_rows` for exact, numeric or structured conditions across
                the complete sheet.
                6. Use `aggregate_excel_sheet` for sums, averages, counts, minima, maxima and
                distinct counts. Calculations must use this tool instead of values copied
                from a profile or range response.
                7. Use `get_excel_range` only when the user asks for specific rows/cells or when
                a small targeted region is needed to understand layout.
                8. If a result says it is truncated, refine the sheet, columns, filters or
                query. Never treat a truncated result as complete.
                9. Return the calculated or retrieved conclusion to the user. Do not include
                entire worksheets or large intermediate tables in the final response.
                """,
            )
        ]


class FieldFinderAgentController(BaseAgentController):
    """Controller for the field finder agent, which extracts structured fields."""

    def __init__(self, config: BaseAgentConfigModel) -> None:
        """
        Initialize the field finder agent controller.

        Args:
            config (BaseAgentConfigModel): The agent configuration.
        """
        super().__init__(config=config)


@dataclass(frozen=True)
class AgentCategory:
    """Registry entry describing how to build and delegate to an agent category."""

    factory: type[BaseAgentController]
    call_tool: Any
    needs_search_deps: bool = False
    needs_excel_deps: bool = False


CATEGORY_REGISTRY: dict[str, AgentCategory] = {
    "index_searcher": AgentCategory(factory=SearchAgentController, call_tool=call_search_agent, needs_search_deps=True),
    "summarizer": AgentCategory(factory=SummarizerAgentController, call_tool=call_summarizer_agent),
    "validator": AgentCategory(factory=ValidatorAgentController, call_tool=call_validator_agent),
    "excel_analyzer": AgentCategory(
        factory=ExcelAnalyzerAgentController, call_tool=call_excel_agent, needs_excel_deps=True
    ),
    "field_finder": AgentCategory(factory=FieldFinderAgentController, call_tool=call_field_finder_agent),
}
