from __future__ import annotations

import datetime
from collections.abc import Callable
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, create_model

from avb_llm.agents.base_agent_model import BaseAgentConfigModel

DEFAULT_FIELD_FINDER_FIELDS: dict[str, str] = {
    "name": "string",
    "age": "integer",
}

JSON_FIELD_TYPE_MAP: dict[str, Any] = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
    "date": datetime.date,
}

OUTPUT_TYPE_REGISTRY: dict[str, Callable[[dict[str, Any] | None], Any]] = {
    "string": lambda fields=None: str,
    "float": lambda fields=None: float,
    "integer": lambda fields=None: int,
    "list": lambda fields=None: list,
    "dictionary": lambda fields=None: dict,
    "tuple": lambda fields=None: tuple,
    "boolean": lambda fields=None: bool,
    "set": lambda fields=None: set,
    "frozenset": lambda fields=None: frozenset,
    "bytes": lambda fields=None: bytes,
    "complex": lambda fields=None: complex,
    "searcher": lambda fields=None: SearcherOutput,
    "validator": lambda fields=None: ValidatorOutput,
    "date": lambda fields=None: datetime.date,
    "datetime": lambda fields=None: datetime.datetime,
    "time": lambda fields=None: datetime.time,
    "field_finder": lambda fields=None: build_field_finder_output(fields),
}


class ValidatorOutput(BaseModel):
    validator_verdict: Literal["VALID", "PARTIALLY_VALID", "INVALID"]
    reason: str


class SearcherOutput(BaseModel):
    content: str
    metadata: dict[str, Any]


def _model_name(field_name: str) -> str:
    """Derive a valid model name from a schema field name.

    Args:
        field_name (str): The schema field name (e.g. ``"coupon_details"``).

    Returns:
        str: A model name (e.g. ``"CouponDetailsModel"``).
    """
    parts: list[str] = [part for part in field_name.replace("-", "_").split("_") if part]
    return "".join(part[:1].upper() + part[1:] for part in parts) + "Model"


def _resolve_field_type(name: str, spec: Any) -> Any:
    """Resolve a single schema entry into a (non-optional) python type.

    A schema entry may be one of:
      * a scalar type string in ``JSON_FIELD_TYPE_MAP`` -> the mapped python type;
      * a nested mapping -> a dynamically built custom sub-model (a class with
        its own attributes) so the agent can extract structured objects;
      * a single-element list ``[<spec>]`` -> a ``list`` of the inner type.

    Args:
        name (str): The field name, used to name nested models and in errors.
        spec (Any): The schema entry describing the field's type.

    Returns:
        Any: The resolved python type, without the optional wrapper.
    """
    if isinstance(spec, dict):
        return _build_model_from_schema(_model_name(name), spec)
    if isinstance(spec, list):
        if len(spec) != 1:
            raise ValueError(f"List schema for field '{name}' must contain exactly one item type, got {spec!r}.")
        field_type = _resolve_field_type(name, spec[0])
        return list[field_type]
    if not isinstance(spec, str) or spec not in JSON_FIELD_TYPE_MAP:
        raise ValueError(f"Unknown field type '{spec}' for field '{name}'. Allowed types: {sorted(JSON_FIELD_TYPE_MAP)}")
    return JSON_FIELD_TYPE_MAP[spec]


def _build_model_from_schema(model_name: str, fields: dict[str, Any]) -> type[BaseModel]:
    """Build a pydantic model from a (possibly nested) field schema.

    Every field is made optional (defaulting to None) and additional properties
    are forbidden. Users only specify the field name and its type; nullability
    and required-ness are always applied automatically. Nested mappings become
    their own custom sub-models, allowing arbitrarily deep structured output.

    Args:
        model_name (str): Name for the generated model.
        fields (dict[str, Any]): Mapping of field name to a schema entry
            (see ``_resolve_field_type`` for the accepted forms).

    Returns:
        type[BaseModel]: A dynamically created pydantic model.
    """
    field_definitions: dict[str, Any] = {
        name: (_resolve_field_type(name, spec) | None, None) for name, spec in fields.items()
    }
    return create_model(
        model_name,
        __config__=ConfigDict(extra="forbid"),
        **field_definitions,
    )


def build_field_finder_output(fields: dict[str, Any] | None = None) -> type[BaseModel]:
    """Build the field-finder output model from a field-name to type mapping.

    Each value may be a scalar type string ("string", "integer", "number",
    "boolean", "date"), a nested mapping that becomes its own custom class, or a
    single-element list for repeated items. Every field is made optional
    (defaulting to None) and additional properties are forbidden.

    Args:
        fields (dict[str, Any] | None): The field schema. Falls back to
            ``DEFAULT_FIELD_FINDER_FIELDS`` when None.

    Returns:
        type[BaseModel]: A dynamically created pydantic model for extraction.
    """
    fields = fields or DEFAULT_FIELD_FINDER_FIELDS
    return _build_model_from_schema("FieldFinderOutput", fields)


def resolve_output_type(config: BaseAgentConfigModel) -> Any:
    """Resolve an agent's output type from its configuration.

    Args:
        config (BaseAgentConfigModel): The agent configuration.

    Returns:
        Any: The configured output type, or ``str`` when ``output_type`` is unset.
    """
    if config.output_type is None:
        return str
    factory: Callable[[dict[str, Any] | None], Any] | None = OUTPUT_TYPE_REGISTRY.get(config.output_type)
    if factory is None:
        raise ValueError(f"Unknown output_type '{config.output_type}'. Allowed: {sorted(OUTPUT_TYPE_REGISTRY)}")
    return factory(config.output_schema)
