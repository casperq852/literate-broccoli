from pydantic_ai import ModelMessage


def keep_recent_messages(messages: list[ModelMessage], n: int = 10) -> list[ModelMessage]:
    """
    Keep only the most recent messages in the context window.

    Args:
        messages (list[ModelMessage]): The full message history.
        n (int): The maximum number of most recent messages to keep.
            Defaults to 10.

    Returns:
        list[ModelMessage]: The last ``n`` messages, in their original order.
    """
    return messages[-n:]


def context_window_manager(messages: list[ModelMessage], n: int = 10) -> list[ModelMessage]:
    """
    Manage the context window by applying the processing functions in order.

    Args:
        messages (list[ModelMessage]): The full message history.
        n (int): The maximum number of most recent messages to keep.
            Defaults to 10.

    Returns:
        list[ModelMessage]: The processed message history that fits the
            context window.
    """
    recent_messages: list[ModelMessage] = keep_recent_messages(messages=messages, n=n)
    return recent_messages
