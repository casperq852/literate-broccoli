from __future__ import annotations

from pathlib import Path
from typing import Any, Literal, get_args

from avb_core import get_logger
from avb_core.loggers import Logger
from pydantic import BaseModel, ConfigDict, Field, field_validator

from avb_llm.helpers import read_yaml_file

logger: Logger = get_logger(name=__name__, structured=True)

ENDPOINTS: list[str] = ["foundry_endpoint", "foundry_api_version", "search_endpoint"]

DEFAULT_REASONING_EFFORT: str = "medium"


class BaseAgentConfigModel(BaseModel):
    model_config: ConfigDict = ConfigDict(extra="forbid")
    type: str = Field(default="chat")
    model: str = Field(default="gpt-5-mini")
    instructions: str = Field(default=("Give clear, practical answers and state uncertainty when needed."))
    reasoning_effort: Literal["none", "minimal", "low", "medium", "high", "xhigh"] = Field(default="low")
    retries: int = Field(default=2, ge=0)
    output_type: str | None = Field(default=None)
    output_schema: dict[str, Any] | None = Field(default=None)
    index_name: str | None = Field(default=None)
    select_fields: list[str] | None = Field(default=None)
    foundry_endpoint: str = Field(
        default="Invalid Foundry endpoint. Please set a valid foundry_endpoint in the app_config."
    )
    foundry_api_version: str = Field(
        default="Invalid API version. Please set a valid foundry_api_version in the app config."
    )
    search_endpoint: str = Field(default="Invalid Search endpoint. Please set a valid search_endpoint in the app config.")

    @field_validator("reasoning_effort", mode="before")
    @classmethod
    def _fallback_reasoning_effort(cls, value: Any) -> str:
        allowed: tuple[str] = get_args(cls.model_fields["reasoning_effort"].annotation)
        if value in allowed:
            return value
        logger.warning(
            message=(
                f"Invalid reasoning_effort {value}; expected one of {list(allowed)}."
                f"Falling back to '{DEFAULT_REASONING_EFFORT}'."
            )
        )
        return DEFAULT_REASONING_EFFORT


class AppConfig(BaseModel):
    agent_configs: dict[str, BaseAgentConfigModel]
    shared_endpoints: dict[str, str] = Field(default_factory=dict)

    @classmethod
    def from_yaml(cls, path: str | Path) -> AppConfig:
        """
        Load and validate an application configuration from a YAML file.

        Shared Azure connection settings declared at the top level of the
        file (``foundry_endpoint``, ``foundry_api_version`` and
        ``azure_search_endpoint``) are propagated onto every agent config,
        so each agent inherits them unless it sets its own value. The
        top-level ``azure_search_endpoint`` maps onto the agent field
        ``search_endpoint``.

        Args:
            path (str | Path): Path to the configuration YAML file.

        Returns:
            AppConfig: The validated application configuration.
        """
        raw: dict[str, Any] = read_yaml_file(location=path)
        endpoints: dict[str, str] = {field: raw[field] for field in ENDPOINTS if field in raw}

        agent_configs: dict[str, Any] = raw.get("agent_configs", {})
        for agent_config in agent_configs.values():
            for field, value in endpoints.items():
                _ = agent_config.setdefault(field, value)

        return cls.model_validate(obj={"agent_configs": agent_configs, "shared_endpoints": endpoints})

    def add_agent_config(self, name: str, config: dict[str, Any]) -> None:
        """
        Register an additional agent config, inheriting shared endpoints.

        The shared Azure connection settings captured from the top level of
        the application configuration are applied to the new agent unless it
        provides its own value, mirroring how :meth:`from_yaml` propagates
        them onto the built-in agents.

        Args:
            name (str): The name under which to register the agent config.
            config (dict[str, Any]): The raw agent configuration fields.
        """
        merged: dict[str, Any] = dict(config)
        for field, value in self.shared_endpoints.items():
            _ = merged.setdefault(field, value)
        self.agent_configs[name] = BaseAgentConfigModel(**merged)
