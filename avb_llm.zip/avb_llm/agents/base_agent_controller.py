from __future__ import annotations

from typing import Any

from pydantic_ai import Agent
from pydantic_ai.capabilities import ProcessHistory
from pydantic_ai.models.openai import OpenAIResponsesModel, OpenAIResponsesModelSettings
from pydantic_ai.providers.azure import AzureProvider

from avb_llm.agents.base_agent_model import BaseAgentConfigModel
from avb_llm.agents.context_window_model import context_window_manager
from avb_llm.agents.helpers import BaseDeps
from avb_llm.agents.output_model import resolve_output_type
from avb_llm.clients import AzureAIFoundryClient


class BaseAgentController:
    def __init__(self, config: BaseAgentConfigModel, sub_agent_names: list[str] | None = None) -> None:
        """
        Initialize the base agent controller with its configuration and defaults.

        Args:
            config (BaseAgentConfigModel): The agent configuration.
            sub_agent_names (list[str] | None): Names of sub-agents this controller may delegate to. Defaults to None.
        """
        self.agent_config: BaseAgentConfigModel = config
        self.deps_type: type[BaseDeps] = BaseDeps
        self.output_type: Any = resolve_output_type(config)
        self.toolsets: list[Any] = []
        self.reasoning_settings: OpenAIResponsesModelSettings = OpenAIResponsesModelSettings(
            openai_reasoning_effort=self.agent_config.reasoning_effort
        )
        self._foundry_client = AzureAIFoundryClient(
            endpoint=config.foundry_endpoint,
            api_version=config.foundry_api_version,
            chat_deployment=config.model,
        )

    def build_agent(self) -> Agent[Any, Any]:
        """
        Build a configured pydantic-ai agent from the controller settings.

        Returns:
            Agent[Any, Any]: The constructed agent with its model, toolsets and capabilities.
        """
        agent: Agent[Any, Any] = Agent(  # type: ignore[no-matching-overload]
            model=self.build_model(),
            deps_type=self.deps_type,
            output_type=self.output_type,
            system_prompt=self.agent_config.instructions,
            toolsets=self.toolsets,
            model_settings=self.reasoning_settings,
            retries=self.agent_config.retries,
            capabilities=[ProcessHistory(processor=context_window_manager)],
        )

        return agent

    def build_model(self) -> OpenAIResponsesModel:
        """
        Build the Azure-backed OpenAI responses model for this agent.

        Returns:
            OpenAIResponsesModel: The model configured with the Azure Foundry provider.
        """
        return OpenAIResponsesModel(
            model_name=self.agent_config.model,
            provider=AzureProvider(openai_client=self._foundry_client.async_client),
        )
