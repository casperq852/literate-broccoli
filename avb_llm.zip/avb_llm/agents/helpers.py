from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pydantic_ai.agent import Agent

from avb_llm.clients.azure_search_controller import AzureAISearchClient
from avb_llm.excel.workspace_controller import ExcelWorkspaceController


@dataclass
class BaseDeps:
    """Base class for agent dependencies shared across all agents."""


@dataclass
class SearchDeps(BaseDeps):
    """Dependencies for agents that query an Azure AI Search index."""

    search_client: AzureAISearchClient
    top_k: int
    select_fields: list[str]
    sources: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class OrchestratorDeps(BaseDeps):
    """Dependencies for the orchestrator, holding its sub-agents and their deps."""

    agents: dict[str, Agent[Any, Any]] = field(default_factory=dict)
    agent_deps: dict[str, BaseDeps] = field(default_factory=dict)
    sources: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class ExcelDeps(BaseDeps):
    """Dependencies for the Excel analyzer agent."""

    workspace_controller: ExcelWorkspaceController
    sources: list[dict[str, Any]] = field(default_factory=list)
