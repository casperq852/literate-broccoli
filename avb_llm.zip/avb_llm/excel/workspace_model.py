from __future__ import annotations

from pathlib import Path

from avb_llm.excel.helpers import to_alphanumeric


def match_workbook_reference(reference: str, available_ids: tuple[str, ...]) -> list[str]:
    """
    Return the workbook IDs matching a reference, in resolution-tier order.

    A caller or language model rarely spells a workbook file name exactly, so
    resolution is attempted from strict to lenient and stops at the first tier
    that yields any candidates:

    1. exact match on the full file name (case-insensitive);
    2. match on the file stem (name without extension);
    3. substring match on the file name or stem;
    4. match on the alphanumeric-only form, which ignores punctuation,
       whitespace and extensions (for example ``"controle fi"`` matching
       ``"[1]Controle_FI.xlsx"``).

    The function is deliberately pure: it takes the reference and the available
    IDs and returns candidates only. It never decides whether zero or several
    candidates is an error; that policy stays in the controller so the model
    is reusable and independently testable.

    Args:
        reference (str): A workbook ID, file stem or partial name to resolve.
        available_ids (tuple[str, ...]): The exact workbook IDs to match
            against.

    Returns:
        list[str]: The matching workbook IDs from the first non-empty tier.
            Empty when the reference is blank or matches nothing; a single
            entry for a unique match; several entries for an ambiguous match.
    """
    normalized: str = reference.strip().casefold()
    if not normalized:
        return []

    exact: list[str] = [name for name in available_ids if name.casefold() == normalized]
    if len(exact) == 1:
        return exact

    stem_matches: list[str] = [name for name in available_ids if Path(name).stem.casefold() == normalized]
    if len(stem_matches) == 1:
        return stem_matches

    partial: list[str] = [
        name for name in available_ids if normalized in name.casefold() or normalized in Path(name).stem.casefold()
    ]
    if partial:
        return partial

    alphanumeric: str = to_alphanumeric(value=reference)
    if alphanumeric:
        return [name for name in available_ids if alphanumeric in to_alphanumeric(value=name)]

    return []
