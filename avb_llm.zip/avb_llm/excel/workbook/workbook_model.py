from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import fastexcel
import polars as pl
from openpyxl.cell.cell import Cell
from openpyxl.utils import get_column_letter
from openpyxl.utils.cell import coordinate_to_tuple
from openpyxl.workbook.workbook import Workbook
from openpyxl.worksheet.worksheet import Worksheet

from avb_llm.excel.helpers import EXCEL_ROW_COLUMN, to_jsonable
from avb_llm.excel.workbook.helpers import (
    CellExplanation,
    ColumnStats,
    FilterCondition,
    FormulaCell,
    FormulaSearchResult,
    SheetProfile,
    WorkbookProfile,
)


def resolve_sheet_name(sheet_name: str, available_names: tuple[str, ...]) -> str | None:
    """
    Return the stored sheet name matching a requested name, or None.

    Matching first tries an exact hit, then a case- and whitespace-insensitive
    comparison, so names that differ only in letter case or surrounding padding
    (for example ``"fixed income"`` versus ``"Fixed Income"``) still resolve.

    Args:
        sheet_name (str): The sheet name to resolve.
        available_names (tuple[str, ...]): The exact stored sheet names to match
            against.

    Returns:
        str | None: The exact stored sheet name matching the input, or None when
            no sheet matches even case-insensitively.
    """
    if sheet_name in available_names:
        return sheet_name

    normalized: str = sheet_name.strip().casefold()
    for candidate in available_names:
        if candidate.strip().casefold() == normalized:
            return candidate

    return None


def ensure_excel_row_column(sheet_data: pl.DataFrame, referenced_columns: set[str]) -> pl.DataFrame:
    """
    Add the synthetic ``excel_row`` column when a caller references it.

    Filter, aggregation and search operations advertise an ``excel_row`` column
    that holds the 1-based Excel row number. That column is virtual: it only
    exists once it is explicitly requested. This adds it when it is referenced
    but not yet present, so column validation and row selection on ``excel_row``
    behave consistently across every operation.

    Args:
        sheet_data (pl.DataFrame): The sheet contents to annotate.
        referenced_columns (set[str]): The column names the caller references.

    Returns:
        pl.DataFrame: The sheet with an ``excel_row`` column when it was
            referenced and missing, otherwise the input unchanged.
    """
    if EXCEL_ROW_COLUMN in referenced_columns and EXCEL_ROW_COLUMN not in sheet_data.columns:
        return sheet_data.with_row_index(name=EXCEL_ROW_COLUMN, offset=1)
    return sheet_data


def get_profile_workbook(
    file_path: str | Path,
    reader: fastexcel.ExcelReader,
    *,
    max_scan_rows: int = 30,
    max_sample_values: int = 30,
) -> WorkbookProfile:
    """
    Profile every sheet in a workbook using only a bounded number of rows.

    Each sheet is read with the supplied fastexcel reader up to
    ``max_scan_rows`` rows. The profile contains per-sheet dimensions, a sample
    of non-empty cell values and the raw first-row values to help callers
    identify headers.

    Args:
        file_path (str | Path): Path to the Excel file, used only to derive the
            workbook identifier.
        reader (fastexcel.ExcelReader): An open reader for the workbook, reused
            across calls instead of being created here.
        max_scan_rows (int): Maximum number of rows to scan per sheet. Defaults
            to 30.
        max_sample_values (int): Maximum number of unique sample values to
            collect per sheet. Defaults to 30.

    Returns:
        WorkbookProfile: A bounded profile containing per-sheet dimensions,
            non-empty cell counts and sample values.

    Raises:
        ValueError: If either limit is less than 1.
    """
    if min(max_scan_rows, max_sample_values) < 1:
        raise ValueError("Profile limits must be at least 1.")

    path: Path = Path(file_path)
    profiles: list[SheetProfile] = []

    for sheet_name in reader.sheet_names:
        sheet = reader.load_sheet(
            idx_or_name=sheet_name,
            header_row=None,
            n_rows=max_scan_rows,
        )
        sample: pl.DataFrame = sheet.to_polars()
        first_row_values: list[Any] = [to_jsonable(value=value) for value in sample.row(index=0)] if sample.height else []

        values: list[str] = []
        seen: set[str] = set()
        non_empty: int = 0
        for row in sample.iter_rows():
            for value in row:
                if value is None:
                    continue
                non_empty += 1
                text: str = str(to_jsonable(value=value))
                if text not in seen and len(values) < max_sample_values:
                    seen.add(text)
                    values.append(text)

        profiles.append(
            SheetProfile(
                sheet_name=sheet_name,
                row_count=sheet.total_height,
                column_count=sheet.width,
                scanned_rows=sample.height,
                non_empty_cells_sample=non_empty,
                first_row_values=first_row_values,
                sample_values=values,
            )
        )

    return WorkbookProfile(workbook_id=path.name, sheets=profiles)


def _detect_header_row(worksheet: Worksheet, *, max_scan_rows: int = 30) -> tuple[int, dict[int, str]]:
    """
    Find the worksheet row that most likely holds the column headers.

    The header row is taken to be the row with the largest number of textual
    labels within the first ``max_scan_rows`` rows. Formula strings (values that
    start with ``"="``) are ignored, because openpyxl exposes stored formulas as
    text and a block of formula cells could otherwise be mistaken for a header.

    Args:
        worksheet (Worksheet): The openpyxl worksheet to inspect.
        max_scan_rows (int): Maximum number of leading rows to scan. Defaults to 30.

    Returns:
        tuple[int, dict[int, str]]: The 1-based header row number and a mapping
            from 1-based Excel column number to the header label found there.
            Both are empty (``0`` and ``{}``) when no textual row is found.
    """
    best_row: int = 0
    best_labels: dict[int, str] = {}
    scan_limit: int = min(worksheet.max_row or max_scan_rows, max_scan_rows)
    for row_index, row in enumerate(worksheet.iter_rows(min_row=1, max_row=scan_limit, values_only=True), start=1):
        labels: dict[int, str] = {
            column_index: value
            for column_index, value in enumerate(row, start=1)
            if isinstance(value, str) and value.strip() and not value.startswith("=")
        }
        if len(labels) > len(best_labels):
            best_row = row_index
            best_labels = labels
    return best_row, best_labels


def _measure_alignment_shift(
    frame: pl.DataFrame,
    *,
    header_row: int,
    header_labels: dict[int, str],
    max_scan_rows: int = 30,
) -> tuple[int, int] | None:
    """
    Find the row and column shift that aligns the raw frame to Excel coordinates.

    The tabular reader silently trims leading empty rows and columns, and it does
    so inconsistently per sheet, which shifts every value away from its true Excel
    position. This locates the header labels inside the raw frame and returns the
    ``(row_shift, column_shift)`` that maps the most header labels back onto their
    true Excel column, effectively a majority vote over all matching labels.

    Args:
        frame (pl.DataFrame): The raw sheet frame with positional column names.
        header_row (int): The 1-based Excel row number of the header.
        header_labels (dict[int, str]): Mapping from 1-based Excel column number
            to the header label expected there.
        max_scan_rows (int): Maximum number of leading frame rows to scan.
            Defaults to 30.

    Returns:
        tuple[int, int] | None: The ``(row_shift, column_shift)`` to pad the frame
            by, or None when no header label could be located in the frame.
    """
    label_values: set[str] = set(header_labels.values())
    best_shift: tuple[int, int] | None = None
    best_score: int = 0
    scan_limit: int = min(frame.height, max_scan_rows)
    for frame_row_index in range(scan_limit):
        row_values: tuple[Any, ...] = frame.row(index=frame_row_index)
        frame_labels: dict[int, str] = {
            column_index: value
            for column_index, value in enumerate(row_values)
            if isinstance(value, str) and value in label_values
        }
        if not frame_labels:
            continue
        for true_column, label in header_labels.items():
            for frame_column, frame_label in frame_labels.items():
                if frame_label != label:
                    continue
                column_shift: int = true_column - 1 - frame_column
                score: int = sum(
                    1 for column, value in frame_labels.items() if header_labels.get(column + column_shift + 1) == value
                )
                if score > best_score:
                    best_score = score
                    best_shift = (header_row - 1 - frame_row_index, column_shift)
    return best_shift


def load_sheet_data(
    sheet_name: str,
    reader: fastexcel.ExcelReader,
    *,
    worksheet: Worksheet | None = None,
) -> pl.DataFrame:
    """
    Read one raw worksheet as a coordinate-preserving Polars DataFrame.

    Columns are named ``column_1``, ``column_2``, ... in sheet order.
    When ``worksheet`` is provided, empty leading rows and columns detected
    by openpyxl are padded back so that every column index matches its real
    Excel column position.

    Args:
        sheet_name (str): Name of the sheet to load.
        reader (fastexcel.ExcelReader): An open reader for the workbook, reused
            across calls instead of being created here.
        worksheet (Worksheet | None): An optional openpyxl worksheet used to
            determine the used-range offset for coordinate alignment. Defaults
            to None.

    Returns:
        pl.DataFrame: The raw sheet contents with coordinate-aligned column
            positions and generic column names.

    Raises:
        KeyError: If the sheet does not exist in the workbook.
    """
    if sheet_name not in reader.sheet_names:
        raise KeyError(f"Sheet not found: {sheet_name}")

    frame: pl.DataFrame = reader.load_sheet(idx_or_name=sheet_name, header_row=None).to_polars()
    frame = frame.rename(mapping={name: f"column_{index + 1}" for index, name in enumerate(iterable=frame.columns)})

    if worksheet is None:
        return frame

    header_row, header_labels = _detect_header_row(worksheet=worksheet)
    if not header_labels:
        return frame

    shift: tuple[int, int] | None = _measure_alignment_shift(
        frame=frame, header_row=header_row, header_labels=header_labels
    )
    if shift is None:
        return frame

    row_offset: int = max(shift[0], 0)
    column_offset: int = max(shift[1], 0)

    if column_offset:
        padding: pl.DataFrame = pl.DataFrame(
            data={f"__pad_column_{index + 1}": [None] * frame.height for index in range(column_offset)}
        )
        frame = padding.hstack(columns=frame)
        frame = frame.rename(mapping={name: f"column_{index + 1}" for index, name in enumerate(iterable=frame.columns)})

    if row_offset and frame.width:
        empty_rows: pl.DataFrame = pl.DataFrame(data={name: [None] * row_offset for name in frame.columns})
        frame = pl.concat(items=[empty_rows, frame], how="vertical_relaxed")

    return frame


def explain_cell_contents(
    sheet_name: str,
    cell_reference: str,
    *,
    worksheet: Worksheet,
    sheet_data: pl.DataFrame,
) -> CellExplanation:
    """
    Describe one cell using formula metadata and cached tabular values.

    The cell value is taken from ``sheet_data`` when a formula is present,
    so the returned value is the computed result rather than the raw formula
    string.

    Args:
        sheet_name (str): Name of the sheet that contains the cell.
        cell_reference (str): A1-style cell reference, e.g. ``"B25"``.
        worksheet (Worksheet): The openpyxl worksheet used to retrieve the
            raw formula, data type and nearby labels.
        sheet_data (pl.DataFrame): The cached tabular data used to resolve
            computed values for formula cells.

    Returns:
        CellExplanation: A compact description containing the cell value,
            optional formula, data type and best-effort row and column labels.
    """
    row_index, column_index = coordinate_to_tuple(coordinate=cell_reference.upper())
    normalized_reference: str = f"{get_column_letter(column_index)}{row_index}"
    cell: Cell = worksheet.cell(row=row_index, column=column_index)

    raw_value: object = cell.value
    formula: str | None = raw_value if isinstance(raw_value, str) and raw_value.startswith("=") else None
    computed_value: object = None
    if row_index <= sheet_data.height and column_index <= sheet_data.width:
        computed_value = sheet_data[row_index - 1, column_index - 1]

    value: object = computed_value if formula is not None else raw_value
    return CellExplanation(
        sheet_name=sheet_name,
        cell=normalized_reference,
        value=to_jsonable(value=value),
        formula=formula,
        data_type=getattr(cell, "data_type", None),
        column_header=to_jsonable(value=worksheet.cell(row=1, column=column_index).value),
        row_label=to_jsonable(value=worksheet.cell(row=row_index, column=1).value),
    )


def _search_mask(
    sheet_data: pl.DataFrame,
    query: str,
    *,
    regex: bool,
    case_sensitive: bool,
    columns: list[str] | None,
) -> pl.Expr:
    """
    Build a Polars boolean expression that matches rows containing the query.

    Evaluates the query against the given columns using literal, regex or
    case-insensitive matching and combines the per-column matches with a
    horizontal OR.

    Args:
        sheet_data (pl.DataFrame): The sheet data to search.
        query (str): The search term to match against the columns.
        regex (bool): Whether to treat the query as a regular expression.
        case_sensitive (bool): Whether the match should be case sensitive.
        columns (list[str] | None): Columns to search; all columns when None.

    Returns:
        pl.Expr: A boolean expression that is True for matching rows.

    Raises:
        ValueError: If the query is empty.
        KeyError: If any requested column is not present in the data.
    """
    if not query:
        raise ValueError("query must not be empty.")

    search_columns: list[str] = columns or sheet_data.columns
    unknown: list[str] = sorted(set(search_columns).difference(sheet_data.columns))
    if unknown:
        raise KeyError(f"Unknown columns: {', '.join(unknown)}")
    if not search_columns:
        return pl.lit(value=False)

    if regex:
        re.compile(pattern=query)

    expressions: list[pl.Expr] = []
    for name in search_columns:
        text: pl.Expr = pl.col(name).cast(dtype=pl.String, strict=False).fill_null(value="")
        if case_sensitive:
            match: pl.Expr = text.str.contains(pattern=query, literal=not regex, strict=False)
        elif regex:
            match: pl.Expr = text.str.contains(pattern=f"(?i){query}", strict=False)
        else:
            match: pl.Expr = text.str.to_lowercase().str.contains(pattern=query.lower(), literal=True, strict=False)
        expressions.append(match.fill_null(value=False))

    return pl.any_horizontal(expressions)


def search_row_contents(
    sheet_data: pl.DataFrame,
    query: str,
    *,
    regex: bool = False,
    case_sensitive: bool = False,
    columns: list[str] | None = None,
) -> pl.DataFrame:
    """
    Return all rows containing at least one cell matching the query.

    Matching is performed with vectorized Polars string operations. Each
    matching row is annotated with its 1-based Excel row number in an
    ``excel_row`` column.

    Args:
        sheet_data (pl.DataFrame): The complete sheet contents to search.
        query (str): The text or regular expression to look for.
        regex (bool): Whether to treat ``query`` as a regular expression.
            Defaults to False.
        case_sensitive (bool): Whether the match is case-sensitive. Defaults
            to False.
        columns (list[str] | None): Restrict the search to these column names.
            Searches all columns when None. Defaults to None.

    Returns:
        pl.DataFrame: The matching rows with an added ``excel_row`` column
            containing the 1-based row number. Empty when nothing matches.

    Raises:
        ValueError: If ``query`` is empty.
        KeyError: If any column in ``columns`` does not exist in ``sheet_data``.
    """
    if sheet_data.width == 0:
        return pl.DataFrame()

    mask: pl.Expr = _search_mask(
        sheet_data=sheet_data,
        query=query,
        regex=regex,
        case_sensitive=case_sensitive,
        columns=columns,
    )
    return sheet_data.with_row_index(name="excel_row", offset=1).filter(mask)


def summarize_columns(
    sheet_data: pl.DataFrame,
    *,
    columns: list[str] | None = None,
    max_sample_values: int = 5,
) -> list[ColumnStats]:
    """
    Calculate compact descriptive statistics for each requested column.

    Numeric statistics (min, max, mean) are computed only on values that can
    be cast to Float64. String columns will have null numeric statistics.

    Args:
        sheet_data (pl.DataFrame): The complete sheet contents to summarize.
        columns (list[str] | None): Column names to summarize. Summarizes all
            columns when None. Defaults to None.
        max_sample_values (int): Maximum number of unique sample values to
            include per column. Defaults to 5.

    Returns:
        list[ColumnStats]: One statistics object per column in the order
            requested.

    Raises:
        KeyError: If any requested column does not exist in ``sheet_data``.
        ValueError: If ``max_sample_values`` is less than 1.
    """
    selected: list[str] = columns or sheet_data.columns
    unknown: list[str] = sorted(set(selected).difference(sheet_data.columns))
    if unknown:
        raise KeyError(f"Unknown columns: {', '.join(unknown)}")
    if max_sample_values < 1:
        raise ValueError("max_sample_values must be at least 1.")

    summaries: list[ColumnStats] = []
    for name in selected:
        series: pl.Series = sheet_data[name]
        non_null: pl.Series = series.drop_nulls()
        numeric: pl.Series = non_null.cast(dtype=pl.Float64, strict=False).drop_nulls()
        samples: list[Any] = non_null.unique(maintain_order=True).head(n=max_sample_values).to_list()
        numeric_mean = numeric.mean() if len(numeric) else None
        summaries.append(
            ColumnStats(
                column=name,
                dtype=str(series.dtype),
                non_null_count=len(non_null),
                null_count=series.null_count(),
                distinct_count=non_null.n_unique(),
                minimum=to_jsonable(value=numeric.min()) if len(numeric) else None,
                maximum=to_jsonable(value=numeric.max()) if len(numeric) else None,
                mean=float(numeric_mean) if isinstance(numeric_mean, (int, float)) else None,
                sample_values=[to_jsonable(value=value) for value in samples],
            )
        )
    return summaries


def filter_sheet_data(
    sheet_data: pl.DataFrame,
    *,
    filters: list[FilterCondition],
) -> pl.DataFrame:
    """
    Apply a declarative filter plan to the complete sheet DataFrame.

    Each ``FilterCondition`` specifies one column, one comparison operator and
    an optional value. All conditions are combined with a logical AND. Type
    coercion is applied where necessary so that numeric comparisons work on
    mixed-type columns.

    Args:
        sheet_data (pl.DataFrame): The complete sheet contents to filter.
        filters (list[FilterCondition]): The filter conditions to apply. Returns
            the full DataFrame unchanged when the list is empty.

    Returns:
        pl.DataFrame: The rows satisfying all filter conditions.

    Raises:
        KeyError: If any filter references a column that does not exist.
        ValueError: If a filter operator requires a value but ``value`` is None,
            or if the ``in`` operator receives a non-list value.
    """
    if not filters:
        return sheet_data

    referenced: set[str] = {condition.column for condition in filters}
    sheet_data = ensure_excel_row_column(sheet_data=sheet_data, referenced_columns=referenced)

    unknown: list[str] = sorted(referenced.difference(sheet_data.columns))
    if unknown:
        raise KeyError(f"Unknown columns: {', '.join(unknown)}")

    expressions: list[pl.Expr] = []
    for condition in filters:
        source: pl.Expr = pl.col(condition.column)
        operator: str = condition.operator
        value: Any = condition.value

        if operator == "is_null":
            expression: pl.Expr = source.is_null()
        elif operator == "is_not_null":
            expression = source.is_not_null()
        elif operator in {"contains", "starts_with", "ends_with"}:
            if value is None:
                raise ValueError(f"Filter operator {operator!r} requires a value.")
            text: pl.Expr = source.cast(dtype=pl.String, strict=False)
            text_value: str = str(value)
            expression = {
                "contains": text.str.contains(pattern=text_value, literal=True),
                "starts_with": text.str.starts_with(prefix=text_value),
                "ends_with": text.str.ends_with(suffix=text_value),
            }[operator]
        elif operator == "in":
            if not isinstance(value, list):
                raise ValueError("Filter operator 'in' requires a list value.")
            if any(isinstance(item, str) for item in value):
                expression = source.cast(dtype=pl.String, strict=False).is_in(other=[str(item) for item in value])
            else:
                expression = source.is_in(other=value)
        else:
            if value is None:
                raise ValueError(f"Filter operator {operator!r} requires a value.")
            comparable: pl.Expr = source
            comparable_value: Any = value
            if isinstance(value, str):
                comparable = source.cast(dtype=pl.String, strict=False)
            elif isinstance(value, (int, float)) and not isinstance(value, bool):
                comparable = source.cast(dtype=pl.Float64, strict=False)
                comparable_value = float(value)

            expression = {
                "eq": comparable == comparable_value,
                "ne": comparable != comparable_value,
                "gt": comparable > comparable_value,
                "ge": comparable >= comparable_value,
                "lt": comparable < comparable_value,
                "le": comparable <= comparable_value,
            }[operator]

        expressions.append(expression.fill_null(value=False))

    return sheet_data.filter(pl.all_horizontal(expressions))


def aggregate_sheet_data(
    sheet_data: pl.DataFrame,
    *,
    value_columns: list[str],
    operations: list[str],
    group_by: list[str] | None = None,
    filters: list[FilterCondition] | None = None,
    max_groups: int = 100,
) -> tuple[pl.DataFrame, list[str], bool, int]:
    """
    Run safe, explicit Polars aggregations without evaluating arbitrary code.

    The supported operations are: ``sum``, ``mean``, ``min``, ``max``, ``std``,
    ``count`` and ``n_unique``. Each ``(column, operation)`` pair produces one
    output column named ``{column}__{operation}``.

    Args:
        sheet_data (pl.DataFrame): The complete sheet contents to aggregate.
        value_columns (list[str]): Column names to aggregate.
        operations (list[str]): Aggregation operations to apply. Every
            operation is applied to every value column.
        group_by (list[str] | None): Column names to group by before
            aggregating. No grouping is applied when None. Defaults to None.
        filters (list[FilterCondition] | None): Optional filters applied before
            aggregation. Defaults to None.
        max_groups (int): Maximum number of groups (or rows) to return. Defaults
            to 100.

    Returns:
        tuple[pl.DataFrame, list[str], bool, int]: The aggregated result, the
            list of output metric column names, a truncation flag and the count
            of rows after filtering.

    Raises:
        ValueError: If any operation is not supported, or if ``value_columns``
            or ``operations`` is empty, or if ``max_groups`` is less than 1.
        KeyError: If any requested column does not exist in ``sheet_data``.
    """
    supported: set[str] = {"sum", "mean", "min", "max", "std", "count", "n_unique"}
    invalid_operations: list[str] = sorted(set(operations).difference(supported))
    if invalid_operations:
        raise ValueError(
            f"Unsupported operations: {', '.join(invalid_operations)}. " f"Supported: {', '.join(sorted(supported))}"
        )
    if not value_columns or not operations:
        raise ValueError("value_columns and operations must not be empty.")
    if max_groups < 1:
        raise ValueError("max_groups must be at least 1.")

    grouping: list[str] = group_by or []
    requested: list[str] = grouping + value_columns
    referenced: set[str] = set(requested) | {condition.column for condition in filters or []}
    sheet_data = ensure_excel_row_column(sheet_data=sheet_data, referenced_columns=referenced)

    filtered_data: pl.DataFrame = filter_sheet_data(sheet_data=sheet_data, filters=filters or [])
    unknown: list[str] = sorted(set(requested).difference(sheet_data.columns))
    if unknown:
        raise KeyError(f"Unknown columns: {', '.join(unknown)}")

    expressions: list[pl.Expr] = []
    metric_names: list[str] = []
    for column in value_columns:
        for operation in operations:
            alias: str = f"{column}__{operation}"
            metric_names.append(alias)
            source: pl.Expr = pl.col(column)
            if operation in {"sum", "mean", "std"}:
                source = source.cast(dtype=pl.Float64, strict=False)
            expression: pl.Expr = {
                "sum": source.sum(),
                "mean": source.mean(),
                "min": source.min(),
                "max": source.max(),
                "std": source.std(),
                "count": source.count(),
                "n_unique": source.n_unique(),
            }[operation]
            expressions.append(expression.alias(name=alias))

    if grouping:
        result: pl.DataFrame = filtered_data.group_by(grouping, maintain_order=True).agg(expressions)
    else:
        result = filtered_data.select(expressions)

    truncated: bool = result.height > max_groups
    return result.head(n=max_groups), metric_names, truncated, filtered_data.height


def search_workbook_formulas(
    workbook_formulas: Workbook,
    *,
    sheet_name: str | None = None,
    query: str | None = None,
    case_sensitive: bool = False,
    max_results: int = 100,
) -> FormulaSearchResult:
    """
    Search formula cells in a workbook and return a bounded result.

    Iterates worksheet rows and stops early once ``max_results`` formulas have
    been collected, setting ``truncated`` to True on the result.

    Args:
        workbook_formulas (Workbook): The openpyxl workbook loaded with
            ``data_only=False`` so formulas are preserved as strings.
        sheet_name (str | None): Restrict the search to this sheet. Searches
            all sheets when None. Defaults to None.
        query (str | None): Optional substring to match against formula text.
            Returns all formulas when None. Defaults to None.
        case_sensitive (bool): Whether the query match is case-sensitive.
            Defaults to False.
        max_results (int): Maximum number of formula cells to return. Defaults
            to 100.

    Returns:
        FormulaSearchResult: The matching formula cells and a ``truncated``
            flag indicating whether the result was cut off.

    Raises:
        ValueError: If ``max_results`` is less than 1.
        KeyError: If ``sheet_name`` is provided but does not exist in the
            workbook.
    """
    if max_results < 1:
        raise ValueError("max_results must be at least 1.")
    if sheet_name is not None and sheet_name not in workbook_formulas.sheetnames:
        raise KeyError(f"Sheet not found: {sheet_name}")

    worksheets: list[Worksheet] = (
        [workbook_formulas[sheet_name]] if sheet_name is not None else workbook_formulas.worksheets
    )
    needle: str | None = query if case_sensitive or query is None else query.lower()
    formulas: list[FormulaCell] = []

    for worksheet in worksheets:
        for row in worksheet.iter_rows():
            for cell in row:
                value: object = cell.value
                if not isinstance(value, str) or not value.startswith("="):
                    continue
                candidate: str = value if case_sensitive else value.lower()
                if needle is not None and needle not in candidate:
                    continue
                if len(formulas) == max_results:
                    return FormulaSearchResult(formulas=formulas, truncated=True)
                formulas.append(
                    FormulaCell(
                        sheet_name=worksheet.title,
                        cell=cell.coordinate,
                        formula=value,
                    )
                )

    return FormulaSearchResult(formulas=formulas, truncated=False)
