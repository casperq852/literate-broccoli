from __future__ import annotations

import threading
from _thread import RLock
from functools import cached_property
from pathlib import Path
from typing import TYPE_CHECKING

import fastexcel
import polars as pl
from openpyxl import load_workbook
from openpyxl.workbook.workbook import Workbook

from avb_llm.excel.helpers import EXCEL_ROW_COLUMN, RowSearchResult
from avb_llm.excel.workbook.helpers import (
    AggregationResult,
    CellExplanation,
    ColumnStats,
    ColumnSummaryResult,
    FilterCondition,
    FilteredRowsResult,
    FormulaSearchResult,
    SheetLoadResult,
    SheetRange,
    WorkbookProfile,
    clean_sheet,
    dataframe_to_records,
)
from avb_llm.excel.workbook.workbook_model import (
    aggregate_sheet_data,
    explain_cell_contents,
    filter_sheet_data,
    get_profile_workbook,
    load_sheet_data,
    resolve_sheet_name,
    search_row_contents,
    search_workbook_formulas,
    summarize_columns,
)

if TYPE_CHECKING:
    from openpyxl.workbook.workbook import _WorksheetOrChartsheetLike


class WorkbookController:
    """
    Thread-safe, bounded API for one Excel workbook.

    Manages a fastexcel reader for tabular access and an optional openpyxl
    workbook for formula inspection. All sheet DataFrames are cached after the
    first load. Tool-response sizes are capped by ``max_tool_rows`` and
    ``max_tool_columns``.
    """

    _FORMULA_SUFFIXES: set[str] = {".xlsx", ".xlsm", ".xltx", ".xltm"}

    def __init__(
        self,
        file_path: str | Path,
        *,
        max_tool_rows: int = 25,
        max_tool_columns: int = 30,
    ) -> None:
        """
        Initialize the controller for a single Excel workbook.

        Args:
            file_path (str | Path): Path to the Excel workbook.
            max_tool_rows (int): Maximum number of rows returned in any single
                tool response. Defaults to 25.
            max_tool_columns (int): Maximum number of columns returned in any
                single tool response. Defaults to 30.

        Raises:
            FileNotFoundError: If the file does not exist.
            ValueError: If either tool-output limit is less than 1.
        """
        self.file_path: Path = Path(file_path)
        if not self.file_path.is_file():
            raise FileNotFoundError(f"Excel file not found: {self.file_path}")
        if max_tool_rows < 1 or max_tool_columns < 1:
            raise ValueError("Tool-output limits must be at least 1.")

        self.max_tool_rows: int = max_tool_rows
        self.max_tool_columns: int = max_tool_columns

        self._sheet_cache: dict[str, pl.DataFrame] = {}
        self._lock: RLock = threading.RLock()
        self._excel_reader: fastexcel.ExcelReader | None = None
        self._sheet_names: tuple[str, ...] = tuple(self.reader.sheet_names)

    @cached_property
    def reader(self) -> fastexcel.ExcelReader:
        """
        Open the workbook once with fastexcel for tabular access.

        The reader is created lazily on first use and reused for every sheet
        read and profile, avoiding a new file parse on each call.

        Returns:
            fastexcel.ExcelReader: The reusable fastexcel reader.
        """
        if not self._excel_reader:
            self._excel_reader = fastexcel.read_excel(source=self.file_path)
        return self._excel_reader

    @property
    def workbook_id(self) -> str:
        """
        Return the workbook identifier, which is the file name.

        Returns:
            str: The file name of the workbook (without directory path).
        """
        return self.file_path.name

    @property
    def sheet_names(self) -> list[str]:
        """
        Return the sheet names in workbook order.

        Returns:
            list[str]: The sheet names as they appear in the workbook.
        """
        return list(self._sheet_names)

    @property
    def supports_formula_inspection(self) -> bool:
        """
        Indicate whether the workbook format supports formula inspection.

        Formula inspection requires an OOXML format (.xlsx, .xlsm, .xltx,
        .xltm).

        Returns:
            bool: True if the file suffix is an OOXML format, False otherwise.
        """
        return self.file_path.suffix.lower() in self._FORMULA_SUFFIXES

    @cached_property
    def workbook_formulas(self) -> Workbook:
        """
        Load the workbook with openpyxl, keeping formula strings intact.

        The workbook is opened in read-only mode with ``data_only=False`` so
        that formula strings are preserved rather than replaced by cached values.

        Returns:
            Workbook: The openpyxl workbook with formulas intact.

        Raises:
            ValueError: If the workbook format does not support formula
                inspection.
        """
        if not self.supports_formula_inspection:
            raise ValueError(f"Formula inspection is not supported for {self.file_path.suffix}.")
        return load_workbook(
            filename=self.file_path,
            read_only=True,
            data_only=False,
            keep_links=False,
        )

    def profile_workbook(
        self,
        *,
        max_scan_rows: int = 30,
        max_sample_values: int = 30,
    ) -> WorkbookProfile:
        """
        Return a bounded profile to help decide which sheets are relevant.

        Args:
            max_scan_rows (int): Maximum number of rows scanned per sheet.
                Defaults to 30.
            max_sample_values (int): Maximum number of unique sample values
                collected per sheet. Defaults to 30.

        Returns:
            WorkbookProfile: A lightweight profile with per-sheet dimensions
                and sample values.
        """
        with self._lock:
            return get_profile_workbook(
                file_path=self.file_path,
                reader=self.reader,
                max_scan_rows=max_scan_rows,
                max_sample_values=max_sample_values,
            )

    def _resolve_sheet_name(self, sheet_name: str) -> str:
        """
        Resolve a sheet name to its exact spelling, ignoring case and padding.

        Sheet names supplied by callers or language models may differ from the
        stored name only in letter case or surrounding whitespace (for example
        ``"fixed income"`` versus ``"Fixed Income"``). This returns the exact
        stored name for such a match so downstream lookups do not fail.

        Args:
            sheet_name (str): The sheet name to resolve.

        Returns:
            str: The exact stored sheet name matching the input.

        Raises:
            KeyError: If no sheet matches the input, even case-insensitively.
        """
        resolved: str | None = resolve_sheet_name(sheet_name=sheet_name, available_names=self._sheet_names)
        if resolved is not None:
            return resolved

        raise KeyError(f"Sheet not found: {sheet_name}. Available sheets: " f"{', '.join(self._sheet_names)}")

    def _load_sheet(self, sheet_name: str, *, clean: bool = False) -> pl.DataFrame:
        """
        Load and cache one sheet as a coordinate-preserving Polars DataFrame.

        The sheet is read once and stored in the internal cache; subsequent
        calls for the same sheet reuse the cached DataFrame.

        Args:
            sheet_name (str): Name of the sheet to load.
            clean (bool): When True, fully-null rows and columns are removed
                before returning. Defaults to False.

        Returns:
            pl.DataFrame: The raw (or cleaned) sheet contents.

        Raises:
            KeyError: If the sheet does not exist in the workbook.
        """
        sheet_name = self._resolve_sheet_name(sheet_name=sheet_name)

        with self._lock:
            if sheet_name not in self._sheet_cache:
                worksheet: _WorksheetOrChartsheetLike | None = (
                    self.workbook_formulas[sheet_name] if self.supports_formula_inspection else None
                )
                self._sheet_cache[sheet_name] = load_sheet_data(
                    sheet_name=sheet_name,
                    reader=self.reader,
                    worksheet=worksheet,
                )
            raw: pl.DataFrame = self._sheet_cache[sheet_name]
            return clean_sheet(sheet_data=raw) if clean else raw

    def load_complete_sheet(self, sheet_name: str) -> SheetLoadResult:
        """
        Load and cache the complete sheet, then return metadata only.

        The full sheet is cached so that subsequent range, filter and search
        calls can operate on the in-memory DataFrame without re-reading the
        file.

        Args:
            sheet_name (str): Name of the sheet to load.

        Returns:
            SheetLoadResult: Metadata describing the loaded sheet, including
                row count, column count and column names.

        Raises:
            KeyError: If the sheet does not exist in the workbook.
        """
        frame: pl.DataFrame = self._load_sheet(sheet_name)
        return SheetLoadResult(
            sheet_name=sheet_name,
            row_count=frame.height,
            column_count=frame.width,
            columns=frame.columns,
        )

    def get_range(
        self,
        sheet_name: str,
        *,
        start_row: int = 1,
        row_count: int = 10,
        start_column: int = 1,
        column_count: int = 15,
    ) -> SheetRange:
        """
        Return a bounded rectangular range from the cached sheet.

        Args:
            sheet_name (str): Name of the sheet to query.
            start_row (int): 1-based row number of the top-left corner.
                Defaults to 1.
            row_count (int): Number of rows to return. Capped by
                ``max_tool_rows``. Defaults to 10.
            start_column (int): 1-based column number of the top-left corner.
                Defaults to 1.
            column_count (int): Number of columns to return. Capped by
                ``max_tool_columns``. Defaults to 15.

        Returns:
            SheetRange: The requested data slice with truncation metadata.

        Raises:
            ValueError: If any position or size parameter is less than 1.
            KeyError: If the sheet does not exist in the workbook.
        """
        if min(start_row, row_count, start_column, column_count) < 1:
            raise ValueError("Range positions and sizes must be at least 1.")

        frame: pl.DataFrame = self._load_sheet(sheet_name)
        requested_columns: list[str] = frame.columns[start_column - 1 : start_column - 1 + column_count]
        section: pl.DataFrame = frame.slice(offset=start_row - 1, length=row_count).select(requested_columns)
        rows, returned_columns, truncated_columns = dataframe_to_records(
            frame=section,
            max_rows=min(row_count, self.max_tool_rows),
            max_columns=min(column_count, self.max_tool_columns),
        )
        return SheetRange(
            sheet_name=sheet_name,
            start_row=start_row,
            start_column=start_column,
            rows=rows,
            returned_columns=returned_columns,
            truncated_columns=truncated_columns,
        )

    def filter_rows(
        self,
        sheet_name: str,
        *,
        filters: list[FilterCondition],
        max_results: int | None = None,
    ) -> FilteredRowsResult:
        """
        Filter the cached sheet and return a bounded set of matching rows.

        Each row is annotated with its 1-based Excel row number in an
        ``excel_row`` column, which is added before filtering. Filters may
        therefore target ``excel_row`` directly (for example to select a row
        range). All filter conditions are applied with a logical AND.

        Args:
            sheet_name (str): Name of the sheet to filter.
            filters (list[FilterCondition]): The filter conditions to apply.
                May reference any sheet column or the synthetic ``excel_row``
                column.
            max_results (int | None): Maximum number of matching rows to return.
                Capped by ``max_tool_rows``. When None, ``max_tool_rows`` is
                used. Defaults to None.

        Returns:
            FilteredRowsResult: The matching rows with total match count and
                truncation metadata.

        Raises:
            KeyError: If the sheet or a filter column does not exist.
            ValueError: If a filter operator is applied without a required value.
        """
        indexed_sheet: pl.DataFrame = self._load_sheet(sheet_name).with_row_index(name=EXCEL_ROW_COLUMN, offset=1)
        matches: pl.DataFrame = filter_sheet_data(sheet_data=indexed_sheet, filters=filters)
        limit: int = min(max_results or self.max_tool_rows, self.max_tool_rows)
        rows, returned_columns, truncated_columns = dataframe_to_records(
            frame=matches,
            max_rows=limit,
            max_columns=self.max_tool_columns,
        )
        return FilteredRowsResult(
            sheet_name=sheet_name,
            total_matches=matches.height,
            rows=rows,
            returned_columns=returned_columns,
            truncated=matches.height > len(rows),
            truncated_columns=truncated_columns,
        )

    def search_rows(
        self,
        sheet_name: str,
        query: str,
        *,
        regex: bool = False,
        case_sensitive: bool = False,
        search_columns: list[str] | None = None,
        max_results: int | None = None,
    ) -> RowSearchResult:
        """
        Search the cached sheet and return a bounded set of matching rows.

        Each row is annotated with its 1-based Excel row number in an
        ``excel_row`` column. Matching is vectorized with Polars string
        operations.

        Args:
            sheet_name (str): Name of the sheet to search.
            query (str): The text or regular expression to look for.
            regex (bool): Whether to treat ``query`` as a regular expression.
                Defaults to False.
            case_sensitive (bool): Whether the match is case-sensitive. Defaults
                to False.
            search_columns (list[str] | None): Restrict the search to these
                columns. Searches all columns when None. Defaults to None.
            max_results (int | None): Maximum number of matching rows to return.
                Capped by ``max_tool_rows``. When None, ``max_tool_rows`` is
                used. Defaults to None.

        Returns:
            RowSearchResult: The matching rows with total match count and
                truncation metadata.

        Raises:
            ValueError: If ``query`` is empty.
            KeyError: If the sheet or any column in ``search_columns`` does not
                exist.
        """
        frame: pl.DataFrame = self._load_sheet(sheet_name)
        matches: pl.DataFrame = search_row_contents(
            sheet_data=frame,
            query=query,
            regex=regex,
            case_sensitive=case_sensitive,
            columns=search_columns,
        )
        limit: int = min(max_results or self.max_tool_rows, self.max_tool_rows)
        rows, returned_columns, truncated_columns = dataframe_to_records(
            frame=matches,
            max_rows=limit,
            max_columns=self.max_tool_columns,
        )
        return RowSearchResult(
            sheet_name=sheet_name,
            query=query,
            total_matches=matches.height,
            rows=rows,
            returned_columns=returned_columns,
            truncated=matches.height > len(rows),
            truncated_columns=truncated_columns,
        )

    def explain_cell(self, sheet_name: str, cell_reference: str) -> CellExplanation:
        """
        Explain a single cell's value, formula and nearby labels.

        Args:
            sheet_name (str): Name of the sheet that contains the cell.
            cell_reference (str): A1-style cell reference, e.g. ``"B25"``.

        Returns:
            CellExplanation: A compact description of the cell including its
                value, optional formula, data type and best-effort row and
                column labels.

        Raises:
            ValueError: If the workbook format does not support formula
                inspection.
            KeyError: If the sheet does not exist in the workbook.
        """
        if not self.supports_formula_inspection:
            raise ValueError("Cell/formula inspection requires an OOXML workbook.")
        with self._lock:
            return explain_cell_contents(
                sheet_name=sheet_name,
                cell_reference=cell_reference,
                worksheet=self.workbook_formulas[sheet_name],
                sheet_data=self._load_sheet(sheet_name),
            )

    def summarize_columns(
        self,
        sheet_name: str,
        *,
        columns: list[str] | None = None,
        max_sample_values: int = 5,
    ) -> ColumnSummaryResult:
        """
        Return compact descriptive statistics for the requested columns.

        Args:
            sheet_name (str): Name of the sheet to summarize.
            columns (list[str] | None): Column names to summarize. Summarizes
                all columns when None. Defaults to None.
            max_sample_values (int): Maximum number of unique sample values per
                column. Defaults to 5.

        Returns:
            ColumnSummaryResult: Statistics for each requested column, including
                counts, numeric range and sample values.

        Raises:
            KeyError: If the sheet or any column does not exist.
            ValueError: If ``max_sample_values`` is less than 1.
        """
        summaries: list[ColumnStats] = summarize_columns(
            sheet_data=self._load_sheet(sheet_name),
            columns=columns,
            max_sample_values=max_sample_values,
        )
        return ColumnSummaryResult(sheet_name=sheet_name, columns=summaries)

    def aggregate(
        self,
        sheet_name: str,
        *,
        value_columns: list[str],
        operations: list[str],
        group_by: list[str] | None = None,
        filters: list[FilterCondition] | None = None,
        max_groups: int = 50,
    ) -> AggregationResult:
        """
        Aggregate sheet columns using a safe, predefined set of operations.

        Supported operations are: ``sum``, ``mean``, ``min``, ``max``, ``std``,
        ``count`` and ``n_unique``.

        Args:
            sheet_name (str): Name of the sheet to aggregate.
            value_columns (list[str]): Columns to aggregate.
            operations (list[str]): Operations to apply to each value column.
            group_by (list[str] | None): Columns to group by before
                aggregating. No grouping is applied when None. Defaults to None.
            filters (list[FilterCondition] | None): Optional filters applied
                before aggregation. Defaults to None.
            max_groups (int): Maximum number of output rows. Capped by
                ``max_tool_rows``. Defaults to 50.

        Returns:
            AggregationResult: The aggregated result with metric names, source
                and filtered row counts and truncation metadata.

        Raises:
            ValueError: If any operation is not supported, if ``value_columns``
                or ``operations`` is empty, or if the output exceeds the column
                limit.
            KeyError: If the sheet or any column does not exist.
        """
        complete_sheet: pl.DataFrame = self._load_sheet(sheet_name)
        result, metrics, truncated, filtered_row_count = aggregate_sheet_data(
            sheet_data=complete_sheet,
            value_columns=value_columns,
            operations=operations,
            group_by=group_by,
            filters=filters,
            max_groups=min(max_groups, self.max_tool_rows),
        )
        rows, _, truncated_columns = dataframe_to_records(
            frame=result,
            max_rows=self.max_tool_rows,
            max_columns=self.max_tool_columns,
        )
        if truncated_columns:
            raise ValueError(
                "The aggregation creates more output columns than allowed; " "request fewer columns or operations."
            )
        return AggregationResult(
            sheet_name=sheet_name,
            group_by=group_by or [],
            metrics=metrics,
            source_row_count=complete_sheet.height,
            filtered_row_count=filtered_row_count,
            rows=rows,
            truncated=truncated,
        )

    def search_formulas(
        self,
        *,
        sheet_name: str | None = None,
        query: str | None = None,
        case_sensitive: bool = False,
        max_results: int = 100,
    ) -> FormulaSearchResult:
        """
        Search formula cells in the workbook and return a bounded result.

        Args:
            sheet_name (str | None): Restrict the search to this sheet.
                Searches all sheets when None. Defaults to None.
            query (str | None): Optional substring to match against formula
                text. Returns all formulas when None. Defaults to None.
            case_sensitive (bool): Whether the query match is case-sensitive.
                Defaults to False.
            max_results (int): Maximum number of formula cells to return.
                Defaults to 100.

        Returns:
            FormulaSearchResult: The matching formula cells and a ``truncated``
                flag.

        Raises:
            ValueError: If the workbook format does not support formula
                inspection or if ``max_results`` is less than 1.
            KeyError: If ``sheet_name`` is provided but does not exist.
        """
        if not self.supports_formula_inspection:
            raise ValueError("Formula inspection requires an OOXML workbook.")
        with self._lock:
            return search_workbook_formulas(
                workbook_formulas=self.workbook_formulas,
                sheet_name=sheet_name,
                query=query,
                case_sensitive=case_sensitive,
                max_results=max_results,
            )

    def clear_cache(self) -> None:
        """
        Discard every cached artefact so the next access re-reads from disk.

        Clears the cached sheet DataFrames and evicts the fastexcel reader and
        the openpyxl formula workbook (closing the latter). Use this when the
        underlying file may have changed on disk; the reader and workbook are
        reopened lazily on the next access.
        """
        with self._lock:
            self._sheet_cache.clear()
            self.__dict__.pop("reader", None)
            workbook: Workbook | None = self.__dict__.pop("workbook_formulas", None)
            if workbook is not None:
                workbook.close()

    def close(self) -> None:
        """
        Release the file handles held by this controller.

        openpyxl read-only workbooks keep the underlying file open, so this
        releases that handle (and the reader) by delegating to ``clear_cache``.
        The controller stays usable afterwards: the reader and workbook reopen
        lazily on the next access.
        """
        self.clear_cache()
