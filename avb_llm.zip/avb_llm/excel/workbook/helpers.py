from __future__ import annotations

from typing import Any, Literal

import polars as pl
from pydantic import Field

from avb_llm.excel.helpers import ResultModel, to_jsonable


class SheetProfile(ResultModel):
    """Bounded profile of a single worksheet."""

    sheet_name: str
    row_count: int
    column_count: int
    scanned_rows: int
    non_empty_cells_sample: int
    first_row_values: list[Any]
    sample_values: list[str]


class WorkbookProfile(ResultModel):
    """Lightweight profile of a workbook."""

    workbook_id: str
    sheets: list[SheetProfile]


class CellExplanation(ResultModel):
    """Value, formula and nearby labels for one Excel cell."""

    sheet_name: str
    cell: str
    value: Any = None
    formula: str | None = None
    data_type: str | None = None
    column_header: Any = None
    row_label: Any = None


class FormulaCell(ResultModel):
    """One formula cell."""

    sheet_name: str
    cell: str
    formula: str


class FormulaSearchResult(ResultModel):
    """Bounded formula-search result."""

    formulas: list[FormulaCell]
    truncated: bool


class SheetLoadResult(ResultModel):
    """Confirmation that a complete worksheet is available in the cache."""

    sheet_name: str
    row_count: int
    column_count: int
    columns: list[str]


class SheetRange(ResultModel):
    """Bounded rectangular range retrieved from the complete worksheet."""

    sheet_name: str
    start_row: int
    start_column: int
    rows: list[dict[str, Any]]
    returned_columns: list[str]
    truncated_columns: bool = False


class FilterCondition(ResultModel):
    """One safe, declarative filter applied to a complete worksheet."""

    column: str
    operator: Literal[
        "eq",
        "ne",
        "gt",
        "ge",
        "lt",
        "le",
        "contains",
        "starts_with",
        "ends_with",
        "in",
        "is_null",
        "is_not_null",
    ]
    value: Any = None


class FilteredRowsResult(ResultModel):
    """Bounded rows selected from the complete worksheet."""

    sheet_name: str
    total_matches: int
    rows: list[dict[str, Any]]
    returned_columns: list[str]
    truncated: bool
    truncated_columns: bool = False


class ColumnStats(ResultModel):
    """Compact descriptive statistics for one column."""

    column: str
    dtype: str
    non_null_count: int
    null_count: int
    distinct_count: int
    minimum: Any = None
    maximum: Any = None
    mean: float | None = None
    sample_values: list[Any] = Field(default_factory=list)


class ColumnSummaryResult(ResultModel):
    """Column statistics for a worksheet."""

    sheet_name: str
    columns: list[ColumnStats]


class AggregationResult(ResultModel):
    """Bounded grouped or workbook-wide aggregation result."""

    sheet_name: str
    group_by: list[str]
    metrics: list[str]
    source_row_count: int
    filtered_row_count: int
    rows: list[dict[str, Any]]
    truncated: bool


def clean_sheet(sheet_data: pl.DataFrame) -> pl.DataFrame:
    """
    Drop fully-null rows and columns while preserving Excel column names.

    Column names are not renamed; the existing ``column_N`` positional names
    are kept so that coordinate-based lookups remain valid.

    Args:
        sheet_data (pl.DataFrame): The raw sheet contents to clean.

    Returns:
        pl.DataFrame: The sheet with fully-null rows and columns removed.
    """
    if sheet_data.is_empty() and sheet_data.width == 0:
        return sheet_data

    cleaned: pl.DataFrame = sheet_data
    if cleaned.width:
        present: list[pl.Expr] = [pl.col(name).is_not_null() for name in cleaned.columns]
        cleaned = cleaned.filter(pl.any_horizontal(present))

    keep_columns: list[str] = [
        name for name in cleaned.columns if cleaned.height > 0 and cleaned[name].null_count() < cleaned.height
    ]
    return cleaned.select(keep_columns)


def dataframe_to_records(
    frame: pl.DataFrame,
    *,
    max_rows: int,
    max_columns: int,
) -> tuple[list[dict[str, Any]], list[str], bool]:
    """
    Serialize a bounded portion of a DataFrame for an LLM tool result.

    Columns and rows are both capped to protect context-window budgets. Each
    cell value is passed through ``to_jsonable`` before serialization.

    Args:
        frame (pl.DataFrame): The DataFrame to serialize.
        max_rows (int): Maximum number of rows to include.
        max_columns (int): Maximum number of columns to include.

    Returns:
        tuple[list[dict[str, Any]], list[str], bool]: The serialized rows, the
            list of returned column names and a flag indicating whether any
            columns were truncated.

    Raises:
        ValueError: If ``max_rows`` or ``max_columns`` is less than 1.
    """
    if max_rows < 1 or max_columns < 1:
        raise ValueError("max_rows and max_columns must be at least 1.")

    returned_columns: list[str] = frame.columns[:max_columns]
    bounded: pl.DataFrame = frame.select(returned_columns).head(n=max_rows)
    rows: list[dict[str, Any]] = [{name: to_jsonable(value) for name, value in row.items()} for row in bounded.to_dicts()]
    return rows, returned_columns, frame.width > len(returned_columns)
