from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path

from avb_llm.excel.helpers import (
    CrossWorkbookSearchResult,
    RowSearchResult,
    SheetSearchHit,
    WorkbookInfo,
)
from avb_llm.excel.workbook.workbook_controller import WorkbookController
from avb_llm.excel.workspace_model import match_workbook_reference


class ExcelWorkspaceController:
    """
    Manage and resolve multiple Excel workbooks without silent collisions.

    Workbook IDs are derived from file names. Duplicate IDs raise an error
    immediately rather than silently overwriting an existing workbook.
    Reference resolution supports exact, stem and unique partial matching.
    """

    def __init__(self, file_paths: Iterable[str | Path] | None = None) -> None:
        """
        Initialize the workspace with one controller per Excel workbook.

        Args:
            file_paths (Iterable[str | Path] | None): Paths to the Excel
                workbooks to load. Workbook IDs are derived from file names.
                Defaults to None (an empty workspace).

        Raises:
            ValueError: If any two files share the same file name (workbook ID).
            FileNotFoundError: If any file does not exist.
        """
        self._workbooks: dict[str, WorkbookController] = {}
        for file_path in file_paths or ():
            self.add_workbook(file_path=file_path)

    @property
    def workbook_ids(self) -> list[str]:
        """
        Return the IDs of all loaded workbooks.

        Returns:
            list[str]: The workbook IDs in the order they were added.
        """
        return list(self._workbooks)

    def add_workbook(self, file_path: str | Path) -> str:
        """
        Add a workbook to the workspace and return its workbook ID.

        Args:
            file_path (str | Path): Path to the Excel workbook to add.

        Returns:
            str: The workbook ID assigned to the newly added workbook.

        Raises:
            ValueError: If a workbook with the same ID already exists.
            FileNotFoundError: If the file does not exist.
        """
        controller: WorkbookController = WorkbookController(file_path=file_path)
        workbook_id: str = controller.workbook_id
        if workbook_id in self._workbooks:
            controller.close()
            existing: Path = self._workbooks[workbook_id].file_path
            raise ValueError(f"Duplicate workbook ID {workbook_id!r}: {existing} and {file_path}.")
        self._workbooks[workbook_id] = controller
        return workbook_id

    def list_workbooks(self) -> list[WorkbookInfo]:
        """
        Return public metadata for all loaded workbooks.

        Returns:
            list[WorkbookInfo]: One entry per workbook containing the ID, sheet
                names and formula inspection support flag.
        """
        return [
            WorkbookInfo(
                workbook_id=workbook_id,
                sheet_names=controller.sheet_names,
                supports_formula_inspection=controller.supports_formula_inspection,
            )
            for workbook_id, controller in self._workbooks.items()
        ]

    def resolve_workbook_id(self, reference: str) -> str:
        """
        Resolve a workbook reference to an exact workbook ID.

        Resolution is attempted in order: exact match, file-stem match, unique
        partial match. An error is raised when the reference is ambiguous or not
        found.

        Args:
            reference (str): A workbook ID, file stem or partial name to resolve.

        Returns:
            str: The exact workbook ID matching the reference.

        Raises:
            KeyError: If the reference is empty, matches no workbook, or is
                ambiguous (matches more than one workbook).
        """
        if not reference.strip():
            raise KeyError("Workbook reference must not be empty.")

        candidates: list[str] = match_workbook_reference(reference=reference, available_ids=tuple(self.workbook_ids))
        if len(candidates) == 1:
            return candidates[0]
        if candidates:
            raise KeyError(f"Ambiguous workbook reference {reference!r}. Matches: " f"{', '.join(candidates)}")

        available: str = ", ".join(self.workbook_ids) or "none"
        raise KeyError(f"Workbook not found: {reference}. Available workbooks: {available}")

    def get_workbook(self, workbook_reference: str) -> WorkbookController:
        """
        Return the controller for a workbook identified by a flexible reference.

        The reference is resolved with ``resolve_workbook_id``, supporting
        exact, stem and unique partial matches.

        Args:
            workbook_reference (str): A workbook ID, file stem or partial name.

        Returns:
            WorkbookController: The controller managing the requested
                workbook.

        Raises:
            KeyError: If the reference cannot be resolved to a unique workbook.
        """
        return self._workbooks[self.resolve_workbook_id(workbook_reference)]

    def search_workbooks(
        self,
        query: str,
        *,
        regex: bool = False,
        case_sensitive: bool = False,
        max_rows_per_sheet: int = 5,
        max_hits: int = 20,
    ) -> CrossWorkbookSearchResult:
        """
        Search every sheet of every workbook and return a bounded set of hits.

        Each workbook sheet is searched with the same vectorized row search used
        by ``WorkbookController.search_rows``. Results are capped both per
        sheet (``max_rows_per_sheet``) and in total number of matching sheets
        (``max_hits``) to keep the response small. Because each searched sheet is
        loaded into its controller cache, prefer a specific workbook tool when
        the target workbook is already known.

        Args:
            query (str): The text or regular expression to look for.
            regex (bool): Whether to treat ``query`` as a regular expression.
                Defaults to False.
            case_sensitive (bool): Whether the match is case-sensitive. Defaults
                to False.
            max_rows_per_sheet (int): Maximum number of matching rows returned
                per sheet. Defaults to 5.
            max_hits (int): Maximum number of matching sheets returned across all
                workbooks. Defaults to 20.

        Returns:
            CrossWorkbookSearchResult: The matching sheets with their bounded
                rows and a ``truncated`` flag set when ``max_hits`` was reached.

        Raises:
            ValueError: If ``query`` is empty.
        """
        hits: list[SheetSearchHit] = []
        for workbook_id, controller in self._workbooks.items():
            for sheet_name in controller.sheet_names:
                result: RowSearchResult = controller.search_rows(
                    sheet_name=sheet_name,
                    query=query,
                    regex=regex,
                    case_sensitive=case_sensitive,
                    max_results=max_rows_per_sheet,
                )
                if result.total_matches == 0:
                    continue
                if len(hits) >= max_hits:
                    return CrossWorkbookSearchResult(
                        query=query,
                        hits=hits,
                        total_hits=len(hits),
                        truncated=True,
                    )
                hits.append(
                    SheetSearchHit(
                        workbook_id=workbook_id,
                        sheet_name=sheet_name,
                        total_matches=result.total_matches,
                        rows=result.rows,
                        returned_columns=result.returned_columns,
                        truncated_columns=result.truncated_columns,
                    )
                )
        return CrossWorkbookSearchResult(
            query=query,
            hits=hits,
            total_hits=len(hits),
            truncated=False,
        )

    def close(self) -> None:
        """
        Release the file handles held by every workbook controller.

        Each controller drops its cached data and closes its reader and formula
        workbook. The workspace and its workbooks stay usable afterwards;
        resources are reopened lazily on the next access.
        """
        for controller in self._workbooks.values():
            controller.close()
