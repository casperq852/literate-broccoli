from __future__ import annotations

import math
import re
from datetime import date, datetime, time
from decimal import Decimal
from typing import Any

from pydantic import BaseModel, ConfigDict

# Name of the synthetic column that carries the 1-based Excel row number.
EXCEL_ROW_COLUMN: str = "excel_row"


class ResultModel(BaseModel):
    """Immutable base class for compact agent-facing results."""

    model_config = ConfigDict(frozen=True)


def to_jsonable(value: Any) -> bool | int | float | str | None:
    """
    Convert one cell value to a strict JSON-compatible representation.

    Non-finite floats (``inf``, ``-inf``, ``nan``) are coerced to ``None``.
    ``datetime``, ``date`` and ``time`` values are serialized as ISO-8601
    strings. All other types fall back to ``str()``.

    Args:
        value (Any): The raw cell value to convert.

    Returns:
        bool | int | float | str | None: A JSON-serializable value: ``None``,
            ``bool``, ``int``, ``float``, ``str`` or an ISO-8601 date/time
            string.
    """
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, Decimal):
        numeric: float = float(value)
        return numeric if math.isfinite(numeric) else None
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if isinstance(value, str):
        return value
    return str(value)


def to_alphanumeric(value: str) -> str:
    """
    Reduce a string to its lower-case alphanumeric characters.

    Punctuation, whitespace and file extensions differ between how a workbook is
    named and how a caller or language model refers to it. Comparing only the
    alphanumeric characters makes reference resolution robust to those cosmetic
    differences.

    Args:
        value (str): The string to normalize.

    Returns:
        str: The lower-cased string with every non-alphanumeric character removed.
    """
    return re.sub(pattern=r"[^0-9a-z]", repl="", string=value.casefold())


def build_excel_source(
    workbook_reference: str,
    sheet_name: str | None = None,
    reference: str | None = None,
    detail: str | None = None,
) -> dict[str, Any]:
    """
    Build one Excel provenance record for the shared sources list.

    The record is shaped like the search-index source records so the existing
    deduplication and rendering treat Excel evidence the same way. Records are
    grouped per workbook and sheet, so several cited cells from one sheet
    collapse into a single source that carries one snippet per citation.

    Args:
        workbook_reference (str): The workbook the evidence came from, as the
            caller referred to it.
        sheet_name (str | None): The sheet the evidence came from. Defaults to
            None.
        reference (str | None): The cell, range or column the evidence points
            to, for example ``"E13"`` or ``"B2:D10"``. Defaults to None.
        detail (str | None): A short human description of the evidence, such as
            a cell value and formula. Defaults to None.

    Returns:
        dict[str, Any]: A source record with an ``id`` that groups by workbook
            and sheet, a ``title`` and a ``content`` snippet.
    """
    identifier: str = workbook_reference if sheet_name is None else f"{workbook_reference} | {sheet_name}"
    title: str = workbook_reference if sheet_name is None else f"{workbook_reference} - {sheet_name}"
    snippet: str = " - ".join(part for part in (reference, detail) if part)
    return {"id": identifier, "title": title, "content": snippet}


class RowSearchResult(ResultModel):
    """Bounded rows matching a search query."""

    sheet_name: str
    query: str
    total_matches: int
    rows: list[dict[str, Any]]
    returned_columns: list[str]
    truncated: bool
    truncated_columns: bool = False


class WorkbookInfo(ResultModel):
    """Public workspace metadata for one workbook."""

    workbook_id: str
    sheet_names: list[str]
    supports_formula_inspection: bool


class SheetSearchHit(ResultModel):
    """Bounded search matches from one worksheet in a cross-workbook search."""

    workbook_id: str
    sheet_name: str
    total_matches: int
    rows: list[dict[str, Any]]
    returned_columns: list[str]
    truncated_columns: bool = False


class CrossWorkbookSearchResult(ResultModel):
    """Bounded search result aggregated across every workbook in the workspace."""

    query: str
    hits: list[SheetSearchHit]
    total_hits: int
    truncated: bool
